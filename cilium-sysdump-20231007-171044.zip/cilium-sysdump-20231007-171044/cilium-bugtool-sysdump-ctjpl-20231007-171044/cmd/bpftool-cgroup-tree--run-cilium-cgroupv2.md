CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2
12252    cgroup_inet4_connect multi           cil_sock4_connect
12257    cgroup_inet6_connect multi           cil_sock6_connect
12253    cgroup_inet4_post_bind multi           cil_sock4_post_bind
12250    cgroup_inet6_post_bind multi           cil_sock6_post_bind
12258    cgroup_udp4_sendmsg multi           cil_sock4_sendmsg
12254    cgroup_udp6_sendmsg multi           cil_sock6_sendmsg
12256    cgroup_udp4_recvmsg multi           cil_sock4_recvmsg
12255    cgroup_udp6_recvmsg multi           cil_sock6_recvmsg
12259    cgroup_inet4_getpeername multi           cil_sock4_getpeername
12251    cgroup_inet6_getpeername multi           cil_sock6_getpeername
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    12879    cgroup_device   multi                          
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    12931    cgroup_inet_ingress multi                          
    12930    cgroup_inet_egress multi                          
    12929    cgroup_device   multi                          
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    12895    cgroup_inet_ingress multi                          
    12894    cgroup_inet_egress multi                          
    12893    cgroup_device   multi                          
/run/cilium/cgroupv2/system.slice/snap.canonical-livepatch.canonical-livepatchd.service
    97       cgroup_device                                  
/run/cilium/cgroupv2/system.slice/upower.service
    12891    cgroup_inet_ingress multi                          
    12890    cgroup_inet_egress multi                          
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    12875    cgroup_device   multi                          
/run/cilium/cgroupv2/system.slice/systemd-timesyncd.service
    12920    cgroup_device   multi                          
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    12872    cgroup_inet_ingress multi                          
    12871    cgroup_inet_egress multi                          
    12870    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc154410_0982_4eb4_be49_d47d9c19b139.slice/cri-containerd-c623072859e200ff36169cdc6fe9a4863cfeb1969c775e2218db54ec8f1f286e.scope
    12740    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poddc154410_0982_4eb4_be49_d47d9c19b139.slice/cri-containerd-90de36f1d964f6c8d748b0e4c188cf05974dddf04c0bfe8da655ab7fb90431eb.scope
    12618    cgroup_device   multi                          
    12881    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80278260_16e6_4292_9a36_ae8093528d7e.slice/cri-containerd-b96ad47b0c085e7c8950751d45114280148996742ec311781f202cfa8fd98b69.scope
    2400     cgroup_device   multi                          
    12938    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod80278260_16e6_4292_9a36_ae8093528d7e.slice/cri-containerd-3a73384a6cc68c83fa1eb0558739ecaecdad8f54b9278b68d80f90510716495f.scope
    2404     cgroup_device   multi                          
    12906    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod867ca692_571e_40fb_937f_0ca72e88d82d.slice/cri-containerd-6cdfce74461bbf449258a5ecf6517b3f09db010566bc6f5f95cace1dd964b4b3.scope
    12437    cgroup_device   multi                          
    12903    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod867ca692_571e_40fb_937f_0ca72e88d82d.slice/cri-containerd-95f26d3996f32a74a18c28199a7dfee1488d784b97da28ec28aca34f38f19df2.scope
    12441    cgroup_device   multi                          
    12937    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf4d5a106_3536_40ab_b2a7_3b59d4b5e144.slice/cri-containerd-585717adf094d425e38da9c0c417b01fc0b977e75f31150cce4a2f7346987866.scope
    26389    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podce23c558_5271_48a2_8bf9_22857553a8d4.slice/cri-containerd-c4938e1f30acce36cda68e5a98b65297c5dce858c042a4f5540c12e7ecbaf060.scope
    12868    cgroup_device   multi                          
    12878    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podce23c558_5271_48a2_8bf9_22857553a8d4.slice/cri-containerd-bb03424933c079c89c3bb7c79efcef8aca3f4de81b071e07a1baccbed2887348.scope
    12856    cgroup_device   multi                          
    12888    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podce23c558_5271_48a2_8bf9_22857553a8d4.slice/cri-containerd-8a2c89a4d4f8a90bcfadaeeaa93aa05bf432c16a464abcfeb0ef3eca01d6cf8a.scope
    12826    cgroup_device   multi                          
    12889    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podce23c558_5271_48a2_8bf9_22857553a8d4.slice/cri-containerd-7f75836952caa952d8b3f4d591e2994680fd2625d3d04c86199706776827be7f.scope
    12860    cgroup_device   multi                          
    12917    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod856435d1_59a6_4a4f_b6e4_ddae1c0763fc.slice/cri-containerd-aa8a048ca9ad5d15123c049fe04109f2a7c123074bbe8918196c163b9df245f6.scope
    12583    cgroup_device   multi                          
    12933    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod856435d1_59a6_4a4f_b6e4_ddae1c0763fc.slice/cri-containerd-9c22eb5c70b1ca8aa92c20156a883925eceb5e3da680dc9183640d008d9b1f50.scope
    12555    cgroup_device   multi                          
    12886    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4a6f6cce_bfa0_4449_b393_973016fc808c.slice/cri-containerd-519d7f124183c89617944780b8ee147ae01547e6912daf3dce5931665c996ab4.scope
    7111     cgroup_device   multi                          
    12907    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4a6f6cce_bfa0_4449_b393_973016fc808c.slice/cri-containerd-e16b929dcdbcb0e2367ee1d6a4f38903c7fa130a5bdbc9b85c94a8f640d5d25b.scope
    7172     cgroup_device   multi                          
    12926    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod148be77d_7fb3_4f22_8320_347fcd7a9e7b.slice/cri-containerd-88a3c704a67da1762d8982a907cf3bb9e1d8d4674d3d3f480dd1bf93a331c83a.scope
    12775    cgroup_device   multi                          
    12936    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod148be77d_7fb3_4f22_8320_347fcd7a9e7b.slice/cri-containerd-fc58b46888950608c4af6a07df3244e24501205ae1cfd6ce337ca0281ad03598.scope
    12737    cgroup_device   multi                          
    12934    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod148be77d_7fb3_4f22_8320_347fcd7a9e7b.slice/cri-containerd-6c1c905b5fcf2239163c83b6ce0d5b57317dec5fdd966f5fb51b498e26081c7b.scope
    12771    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod148be77d_7fb3_4f22_8320_347fcd7a9e7b.slice/cri-containerd-f22ef1ee0a0784ef997cd51a011e591e7fd22e5ffd2c8288945a11c9558d95c7.scope
    12778    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34fc6f29_490d_4e89_825e_fc463f0605b6.slice/cri-containerd-c476cf45decb98b01a484cc340f21a37f5a369c4845f38bca8773419a5b6356f.scope
    23081    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod34fc6f29_490d_4e89_825e_fc463f0605b6.slice/cri-containerd-83d3a2f097737b67bf9a9b52a3c333be3cfeb66db21ac99b00bfbadbbd36c3ec.scope
    23085    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod745dc91f_1b8e_450e_aa5a_304d7e0a019f.slice/cri-containerd-17eb17d0a1d877fd1d72d85b46b9763a773df6be508e316eff9fe0af935961bb.scope
    7249     cgroup_device   multi                          
    12908    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod745dc91f_1b8e_450e_aa5a_304d7e0a019f.slice/cri-containerd-95726ff109927f3873b4bdd90f3d0d445e6a0547ce62b81b1cbcfa43e95d6657.scope
    7257     cgroup_device   multi                          
    12874    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod745dc91f_1b8e_450e_aa5a_304d7e0a019f.slice/cri-containerd-932278541a462d4ca76060942476591d3694da9aa6b3de252541eded7375f1c7.scope
    7261     cgroup_device   multi                          
    12899    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8595510b_e8d2_4183_91f6_405637d831a3.slice/cri-containerd-39661a86b0888f80ec7507426b4b99bea602039f131a1b134b05176063a6fd62.scope
    12764    cgroup_device   multi                          
    12912    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod8595510b_e8d2_4183_91f6_405637d831a3.slice/cri-containerd-397ff17b6ae5d448a92ba5cf098b697506cf41a83bce59a4ea53018ff2546017.scope
    12729    cgroup_device   multi                          
    12880    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd12ef655_1151_432a_b906_f10f204a7111.slice/cri-containerd-0cafb4145ae8d4f2e46bf0bf4f28bd322e7a8fbbe2960f659567129bf4c4451d.scope
    12733    cgroup_device   multi                          
    12921    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd12ef655_1151_432a_b906_f10f204a7111.slice/cri-containerd-a299ae51674bc9e41967e5c0b608492c0600b1960e5d37119831424bc27ffe68.scope
    12768    cgroup_device   multi                          
    12887    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod983a8451_4b5a_4a4e_bbef_ed60ec119c77.slice/cri-containerd-796b3a8bc8850d3d95ec41317be2e7d5b43dae9b50a15da7add235c682c31e9e.scope
    12756    cgroup_device   multi                          
    12877    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod983a8451_4b5a_4a4e_bbef_ed60ec119c77.slice/cri-containerd-b4873c2ae8747bf29bf2e72b2b046a4b5532c7785b7b48afcc1cc121b785eb1c.scope
    12711    cgroup_device   multi                          
    12892    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode624170b_a332_4eba_b45e_ae1d89c75517.slice/cri-containerd-6639717f85ea72f363fe7ad1595bc55de472384deaddcf5c2686c830df3ea756.scope
    12744    cgroup_device   multi                          
    12922    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode624170b_a332_4eba_b45e_ae1d89c75517.slice/cri-containerd-13c7ad2ddb8a72a202cf34a252e4bcea1ba037bc6e1bb15cb85f606ecdf53323.scope
    12649    cgroup_device   multi                          
    12911    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f3b53c1_45bb_4c8a_a1f9_3b076f92c98a.slice/cri-containerd-ccc01483db230409ccb02b5d765cdf89df99d808eb3821dac2154fa951e45869.scope
    29067    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0f3b53c1_45bb_4c8a_a1f9_3b076f92c98a.slice/cri-containerd-5e46b06460455c50615566a01710005fe7cef5e24841ef7df433a9d08ede09cb.scope
    29063    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5eb552de_5d55_49a4_ad72_9dd592a941ae.slice/cri-containerd-c8d6ea114c02e113f8ea2c7bd8bc05794cfaa4dbf2a01a5d03592ecee2da55f9.scope
    12864    cgroup_device   multi                          
    12913    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5eb552de_5d55_49a4_ad72_9dd592a941ae.slice/cri-containerd-61a1b68a73a88011f8afcd95232b613adcf586a54cbcf413f48ed4bc7725c4c2.scope
    12822    cgroup_device   multi                          
    12900    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7410f17a_4ddf_466b_9aa2_8ea002e7987a.slice/cri-containerd-071b9cc3ebcf9fe25351de3289eb55e4e63433523528b8e02cb61ec77d809534.scope
    7187     cgroup_device   multi                          
    12925    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7410f17a_4ddf_466b_9aa2_8ea002e7987a.slice/cri-containerd-2060efaeb1b35ec883ba295c9630a1d5a23b23ee34ac4a3c0be99315f88e8da8.scope
    7191     cgroup_device   multi                          
    12914    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3913755c_ed4f_4e5e_b018_cc9345c24050.slice/cri-containerd-b2ca61e4eb983e9e4b9b7022304dc4d7c3f12d57a0bbd7e7bef0efbb70c7a0c2.scope
    12653    cgroup_device   multi                          
    12882    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod3913755c_ed4f_4e5e_b018_cc9345c24050.slice/cri-containerd-8038ef7b9ecc7acc7120542e5532d3a31720200a18a5226f49f028d1893939e3.scope
    12748    cgroup_device   multi                          
    12876    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaaafeded_69c1_40cb_8a1c_66e65abd1f85.slice/cri-containerd-5dab75286e06133e860cbce0c810cefcd70bb5489a24f5874c6b63956aea49e2.scope
    7293     cgroup_device   multi                          
    12924    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podaaafeded_69c1_40cb_8a1c_66e65abd1f85.slice/cri-containerd-6491e69204f6d3cf64eb62d1014fb48bafd1b34a5de79715e0b99e9e2498ee91.scope
    12509    cgroup_device   multi                          
    12896    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0bfdc70_9330_470f_9873_903b18768d81.slice/cri-containerd-528c5e395fe6b2873d507ed501814ceb54b7f007ea2cb472b8aca6ba25e9ac1c.scope
    12852    cgroup_device   multi                          
    12884    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd0bfdc70_9330_470f_9873_903b18768d81.slice/cri-containerd-6d4de3a1891eb40f53a1171a9ee1e876f68a44de96873939ea1f8f2276f01866.scope
    12848    cgroup_device   multi                          
    12897    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1143e2e7_3b32_4829_8b37_c533f8c2e598.slice/cri-containerd-1eedb304d732f6e0864f609630df9d1282e62af425a7e7f15bb5d9344777e28d.scope
    12667    cgroup_device   multi                          
    12902    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1143e2e7_3b32_4829_8b37_c533f8c2e598.slice/cri-containerd-6eb79966ad1040b81da00b2e4cb3ae3055bcd06060dc66b9897ff8ddc9c0e65a.scope
    12752    cgroup_device   multi                          
    12932    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31844560_2518_4036_8f64_500c6fcdf126.slice/cri-containerd-a833d121587ad256ba1a773ca4a938ebffa7cc82c7e5c913e56541c3385b9612.scope
    12586    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod31844560_2518_4036_8f64_500c6fcdf126.slice/cri-containerd-4fa53bf058bbfc31393acd9f6ce389ef52465b005f9e3909750d56640c747812.scope
    12575    cgroup_device   multi                          
    12915    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc9e8f8d_1568_4428_bd8f_6faa1a354974.slice/cri-containerd-6028145daae26cff76599faad7f046b506dac32f9d8e173059fc48626d11d214.scope
    7164     cgroup_device   multi                          
    12927    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfc9e8f8d_1568_4428_bd8f_6faa1a354974.slice/cri-containerd-5853b98a857924c610a776329dffe99e521d83446e772fbc9366a2193492aa20.scope
    7122     cgroup_device   multi                          
    12898    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod561eabb7_3e7e_479d_b108_9edf354a4ed4.slice/cri-containerd-a8e07f8b054b14cc8b05703621512a55c73a18c51c4c5affd1c93192e02b514a.scope
    12625    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod561eabb7_3e7e_479d_b108_9edf354a4ed4.slice/cri-containerd-dfcce5d75aa41ffca0066170309a918db25e76d91da5d5760e158fd1d796eb93.scope
    12604    cgroup_device   multi                          
    12916    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda7013c5d_de66_44bf_8164_a6b863cdefc8.slice/cri-containerd-c90cbb65cfdb774a081a01cc3ba8e8a3a7d8129af75729ab5720adfc632b8681.scope
    12579    cgroup_device   multi                          
    12901    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda7013c5d_de66_44bf_8164_a6b863cdefc8.slice/cri-containerd-708e6624e475eb1045e57fc8b0663b8accce40bc6aad1f811de5718eb85e731c.scope
    12622    cgroup_device   multi                          
    12935    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda9cc6b8d_1696_4c1b_a184_b02e7c260ee2.slice/cri-containerd-f25240459532fb6f2cd7b4f6d15da06c37a4001f26b12956ecd54921744c1153.scope
    12760    cgroup_device   multi                          
    12928    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-poda9cc6b8d_1696_4c1b_a184_b02e7c260ee2.slice/cri-containerd-c3eda76220494cd548842c1533ad1dbf5f345626f8d397c6fd64f990e5ae86b9.scope
    12716    cgroup_device   multi                          
    12919    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d246214_10a3_4dff_8a30_44b87fabc331.slice/cri-containerd-18602ba6c43293f5659a8d05bc42c17dc90ee84ec30b210fa742d686712ef4c2.scope
    7156     cgroup_device   multi                          
    12918    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod5d246214_10a3_4dff_8a30_44b87fabc331.slice/cri-containerd-b567394cf219fb062266c17b9642f1bd595ef104b4a046c922ac1d4bb84c209a.scope
    7168     cgroup_device   multi                          
    12869    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc0189b2c_d55a_431b_b858_761d8423f782.slice/cri-containerd-677eef45b6e4b09a0b5c952714d9f7438d94e8b150f248f8050f959252022592.scope
    7209     cgroup_device   multi                          
    12873    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podc0189b2c_d55a_431b_b858_761d8423f782.slice/cri-containerd-e2300d4dca331a364649959958b6e0a025024e72694b6670e396039c474e01ff.scope
    7231     cgroup_device   multi                          
    12909    cgroup_device   multi                          
