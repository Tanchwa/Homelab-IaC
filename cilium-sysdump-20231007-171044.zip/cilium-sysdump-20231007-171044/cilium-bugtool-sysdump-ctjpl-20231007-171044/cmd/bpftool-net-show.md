xdp:

tc:
enp0s25(2) clsact/ingress cil_from_netdev-enp0s25 id 12404
enp0s25(2) clsact/egress cil_to_netdev-enp0s25 id 12415
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 12395
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 12372
cilium_host(4) clsact/egress cil_from_host-cilium_host id 12389
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 12265
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 12266
lxc4c3047597631(35) clsact/ingress cil_from_container-lxc4c3047597631 id 12299
lxc7a863e00b5ab(55) clsact/ingress cil_from_container-lxc7a863e00b5ab id 12327
lxcfb97f3359139(57) clsact/ingress cil_from_container-lxcfb97f3359139 id 12271
lxc6b34683b4c68(59) clsact/ingress cil_from_container-lxc6b34683b4c68 id 12316
lxc0666b0e76f82(61) clsact/ingress cil_from_container-lxc0666b0e76f82 id 12356
lxc0813f578bd6f(63) clsact/ingress cil_from_container-lxc0813f578bd6f id 12290
lxca1ac2634066e(67) clsact/ingress cil_from_container-lxca1ac2634066e id 12344
lxc635980f3a45f(71) clsact/ingress cil_from_container-lxc635980f3a45f id 12335
lxc2e76a7ee6054(95) clsact/ingress cil_from_container-lxc2e76a7ee6054 id 12445
lxcd5a3fea4fb9e(99) clsact/ingress cil_from_container-lxcd5a3fea4fb9e id 12547
lxcaae3e7a2fe30(101) clsact/ingress cil_from_container-lxcaae3e7a2fe30 id 12550
lxc1f718abe12f5(103) clsact/ingress cil_from_container-lxc1f718abe12f5 id 12561
lxc1a13fe9d3eba(105) clsact/ingress cil_from_container-lxc1a13fe9d3eba id 12593
lxcf39b2c9b8b13(107) clsact/ingress cil_from_container-lxcf39b2c9b8b13 id 12610
lxc575196045d62(109) clsact/ingress cil_from_container-lxc575196045d62 id 12634
lxc8ebc7c2aca63(111) clsact/ingress cil_from_container-lxc8ebc7c2aca63 id 12639
lxc2eeff20b5f72(113) clsact/ingress cil_from_container-lxc2eeff20b5f72 id 12654
lxc6690af65c315(115) clsact/ingress cil_from_container-lxc6690af65c315 id 12676
lxc13a1d1f4e36f(117) clsact/ingress cil_from_container-lxc13a1d1f4e36f id 12680
lxc24279bc63cf7(119) clsact/ingress cil_from_container-lxc24279bc63cf7 id 12688
lxc4572d400a690(121) clsact/ingress cil_from_container-lxc4572d400a690 id 12703
lxcf7380be6dd83(123) clsact/ingress cil_from_container-lxcf7380be6dd83 id 12719
lxcc68174b20f8a(127) clsact/ingress cil_from_container-lxcc68174b20f8a id 12803
lxcc2a40ff909ee(129) clsact/ingress cil_from_container-lxcc2a40ff909ee id 12816

flow_dissector:

