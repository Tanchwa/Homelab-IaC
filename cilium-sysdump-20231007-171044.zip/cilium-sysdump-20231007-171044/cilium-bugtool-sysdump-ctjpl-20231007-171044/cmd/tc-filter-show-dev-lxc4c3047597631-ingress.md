filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc4c3047597631 direct-action not_in_hw id 12299 tag ab4ebf93d371d20c jited 
