filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcfb97f3359139 direct-action not_in_hw id 12271 tag 72b5d87323c6ea59 jited 
