1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
2: enp0s25: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether 78:2b:cb:8c:aa:dc brd ff:ff:ff:ff:ff:ff
    inet 192.168.1.4/24 metric 100 brd 192.168.1.255 scope global dynamic enp0s25
       valid_lft 63423sec preferred_lft 63423sec
    inet6 fe80::7a2b:cbff:fe8c:aadc/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 02:f8:3a:ed:b2:17 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::f8:3aff:feed:b217/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 42:50:86:19:3f:ca brd ff:ff:ff:ff:ff:ff
    inet 10.0.1.245/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::4050:86ff:fe19:3fca/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 2a:90:82:76:0b:1f brd ff:ff:ff:ff:ff:ff
    inet6 fe80::2890:82ff:fe76:b1f/64 scope link 
       valid_lft forever preferred_lft forever
35: lxc4c3047597631@if34: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether fe:30:6c:94:fe:76 brd ff:ff:ff:ff:ff:ff link-netnsid 1
    inet6 fe80::fc30:6cff:fe94:fe76/64 scope link 
       valid_lft forever preferred_lft forever
55: lxc7a863e00b5ab@if54: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether da:c8:3e:e7:73:71 brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::d8c8:3eff:fee7:7371/64 scope link 
       valid_lft forever preferred_lft forever
57: lxcfb97f3359139@if56: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 0e:b8:aa:de:9d:fa brd ff:ff:ff:ff:ff:ff link-netnsid 7
    inet6 fe80::cb8:aaff:fede:9dfa/64 scope link 
       valid_lft forever preferred_lft forever
59: lxc6b34683b4c68@if58: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether aa:66:00:2f:bc:a7 brd ff:ff:ff:ff:ff:ff link-netnsid 8
    inet6 fe80::a866:ff:fe2f:bca7/64 scope link 
       valid_lft forever preferred_lft forever
61: lxc0666b0e76f82@if60: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 96:95:85:c3:95:0a brd ff:ff:ff:ff:ff:ff link-netnsid 9
    inet6 fe80::9495:85ff:fec3:950a/64 scope link 
       valid_lft forever preferred_lft forever
63: lxc0813f578bd6f@if62: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether d2:8c:dc:38:32:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 10
    inet6 fe80::d08c:dcff:fe38:32b1/64 scope link 
       valid_lft forever preferred_lft forever
67: lxca1ac2634066e@if66: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 42:b4:ae:4b:76:e1 brd ff:ff:ff:ff:ff:ff link-netnsid 11
    inet6 fe80::40b4:aeff:fe4b:76e1/64 scope link 
       valid_lft forever preferred_lft forever
71: lxc635980f3a45f@if70: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:92:fe:fe:94:b3 brd ff:ff:ff:ff:ff:ff link-netnsid 12
    inet6 fe80::1c92:feff:fefe:94b3/64 scope link 
       valid_lft forever preferred_lft forever
95: lxc2e76a7ee6054@if94: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:27:e0:f5:97:31 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::8827:e0ff:fef5:9731/64 scope link 
       valid_lft forever preferred_lft forever
99: lxcd5a3fea4fb9e@if98: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:f3:36:c9:e2:b3 brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::4cf3:36ff:fec9:e2b3/64 scope link 
       valid_lft forever preferred_lft forever
101: lxcaae3e7a2fe30@if100: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ee:48:75:ce:62:8d brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::ec48:75ff:fece:628d/64 scope link 
       valid_lft forever preferred_lft forever
103: lxc1f718abe12f5@if102: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether e6:b1:56:36:7d:6d brd ff:ff:ff:ff:ff:ff link-netnsid 13
    inet6 fe80::e4b1:56ff:fe36:7d6d/64 scope link 
       valid_lft forever preferred_lft forever
105: lxc1a13fe9d3eba@if104: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 66:6f:e3:fc:fc:5d brd ff:ff:ff:ff:ff:ff link-netnsid 14
    inet6 fe80::646f:e3ff:fefc:fc5d/64 scope link 
       valid_lft forever preferred_lft forever
107: lxcf39b2c9b8b13@if106: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 22:fe:ed:bf:dd:93 brd ff:ff:ff:ff:ff:ff link-netnsid 15
    inet6 fe80::20fe:edff:febf:dd93/64 scope link 
       valid_lft forever preferred_lft forever
109: lxc575196045d62@if108: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 96:54:a4:81:dc:fe brd ff:ff:ff:ff:ff:ff link-netnsid 16
    inet6 fe80::9454:a4ff:fe81:dcfe/64 scope link 
       valid_lft forever preferred_lft forever
111: lxc8ebc7c2aca63@if110: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 12:22:85:1c:4b:62 brd ff:ff:ff:ff:ff:ff link-netnsid 17
    inet6 fe80::1022:85ff:fe1c:4b62/64 scope link 
       valid_lft forever preferred_lft forever
113: lxc2eeff20b5f72@if112: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ee:ba:89:43:af:68 brd ff:ff:ff:ff:ff:ff link-netnsid 18
    inet6 fe80::ecba:89ff:fe43:af68/64 scope link 
       valid_lft forever preferred_lft forever
115: lxc6690af65c315@if114: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:95:28:05:34:b3 brd ff:ff:ff:ff:ff:ff link-netnsid 19
    inet6 fe80::8c95:28ff:fe05:34b3/64 scope link 
       valid_lft forever preferred_lft forever
117: lxc13a1d1f4e36f@if116: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:23:00:d8:00:83 brd ff:ff:ff:ff:ff:ff link-netnsid 20
    inet6 fe80::6c23:ff:fed8:83/64 scope link 
       valid_lft forever preferred_lft forever
119: lxc24279bc63cf7@if118: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 76:d4:f9:e7:80:c9 brd ff:ff:ff:ff:ff:ff link-netnsid 21
    inet6 fe80::74d4:f9ff:fee7:80c9/64 scope link 
       valid_lft forever preferred_lft forever
121: lxc4572d400a690@if120: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether de:06:60:36:a8:68 brd ff:ff:ff:ff:ff:ff link-netnsid 22
    inet6 fe80::dc06:60ff:fe36:a868/64 scope link 
       valid_lft forever preferred_lft forever
123: lxcf7380be6dd83@if122: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 6e:38:45:09:3b:5f brd ff:ff:ff:ff:ff:ff link-netnsid 23
    inet6 fe80::6c38:45ff:fe09:3b5f/64 scope link 
       valid_lft forever preferred_lft forever
127: lxcc68174b20f8a@if126: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:6b:51:ee:30:09 brd ff:ff:ff:ff:ff:ff link-netnsid 25
    inet6 fe80::9c6b:51ff:feee:3009/64 scope link 
       valid_lft forever preferred_lft forever
129: lxcc2a40ff909ee@if128: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ae:8c:61:44:74:43 brd ff:ff:ff:ff:ff:ff link-netnsid 26
    inet6 fe80::ac8c:61ff:fe44:7443/64 scope link 
       valid_lft forever preferred_lft forever
