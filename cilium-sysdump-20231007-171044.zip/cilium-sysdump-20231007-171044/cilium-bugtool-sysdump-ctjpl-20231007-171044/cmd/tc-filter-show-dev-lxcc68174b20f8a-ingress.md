filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcc68174b20f8a direct-action not_in_hw id 12803 tag dc0b2c66a380092d jited 
