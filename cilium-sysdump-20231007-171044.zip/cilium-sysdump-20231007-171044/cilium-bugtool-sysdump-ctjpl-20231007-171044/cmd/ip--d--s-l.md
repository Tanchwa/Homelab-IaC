1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00 promiscuity 0 minmtu 0 maxmtu 0 addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
     434761185 3969315      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     434761185 3969315      0       0       0       0 
2: enp0s25: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP mode DEFAULT group default qlen 1000
    link/ether 78:2b:cb:8c:aa:dc brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 9212 addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:00:19.0 
    RX:   bytes  packets errors dropped  missed   mcast           
    22993636724 25810719      0     340       0  380209 
    TX:   bytes  packets errors dropped carrier collsns           
     7327557744 18600597      0       0       0       0 
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 02:f8:3a:ed:b2:17 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         92870    1349      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       5419202   69940      0       0       0       0 
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 42:50:86:19:3f:ca brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       5419202   69940      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         92870    1349      0       0       0       0 
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/ether 2a:90:82:76:0b:1f brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    vxlan external id 0 srcport 0 0 dstport 8472 nolearning ttl auto ageing 300 udpcsum noudp6zerocsumtx noudp6zerocsumrx addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
    5369103190 1994027      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
    5109590891 1514912      0       0       0       0 
35: lxc4c3047597631@if34: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether fe:30:6c:94:fe:76 brd ff:ff:ff:ff:ff:ff link-netnsid 1 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
     163668991  917066      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     127154619 1036669      0       0       0       0 
55: lxc7a863e00b5ab@if54: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether da:c8:3e:e7:73:71 brd ff:ff:ff:ff:ff:ff link-netnsid 6 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       4856867   62202      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       7571998   50487      0       0       0       0 
57: lxcfb97f3359139@if56: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 0e:b8:aa:de:9d:fa brd ff:ff:ff:ff:ff:ff link-netnsid 7 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
    4992292226 1017526      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
    5106654736 1774829      0       0       0       0 
59: lxc6b34683b4c68@if58: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether aa:66:00:2f:bc:a7 brd ff:ff:ff:ff:ff:ff link-netnsid 8 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
     239718987 1218812      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     888687685 1106685      0       0       0       0 
61: lxc0666b0e76f82@if60: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 96:95:85:c3:95:0a brd ff:ff:ff:ff:ff:ff link-netnsid 9 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      19899580  247364      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     767564853  288930      0       0       0       0 
63: lxc0813f578bd6f@if62: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether d2:8c:dc:38:32:b1 brd ff:ff:ff:ff:ff:ff link-netnsid 10 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
    9770695577 4250506      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
    1122057606 4228551      0       0       0       0 
67: lxca1ac2634066e@if66: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 42:b4:ae:4b:76:e1 brd ff:ff:ff:ff:ff:ff link-netnsid 11 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:   bytes packets errors dropped  missed   mcast           
      786773847 7416022      0       0       0       0 
    TX:   bytes packets errors dropped carrier collsns           
    19218464559 7851270      0       0       0       0 
71: lxc635980f3a45f@if70: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 1e:92:fe:fe:94:b3 brd ff:ff:ff:ff:ff:ff link-netnsid 12 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      76355521  527282      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     122543978  456107      0       0       0       0 
95: lxc2e76a7ee6054@if94: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 8a:27:e0:f5:97:31 brd ff:ff:ff:ff:ff:ff link-netnsid 3 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
     323891068 3018224      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     441952310 3546542      0       0       0       0 
99: lxcd5a3fea4fb9e@if98: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 4e:f3:36:c9:e2:b3 brd ff:ff:ff:ff:ff:ff link-netnsid 4 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
          5804      81      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          5956      81      0       0       0       0 
101: lxcaae3e7a2fe30@if100: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ee:48:75:ce:62:8d brd ff:ff:ff:ff:ff:ff link-netnsid 5 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
     128604447 1212721      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     395083245 1209782      0       0       0       0 
103: lxc1f718abe12f5@if102: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether e6:b1:56:36:7d:6d brd ff:ff:ff:ff:ff:ff link-netnsid 13 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         42119     320      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
        195064     355      0       0       0       0 
105: lxc1a13fe9d3eba@if104: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 66:6f:e3:fc:fc:5d brd ff:ff:ff:ff:ff:ff link-netnsid 14 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
          5556      78      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          5556      78      0       0       0       0 
107: lxcf39b2c9b8b13@if106: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 22:fe:ed:bf:dd:93 brd ff:ff:ff:ff:ff:ff link-netnsid 15 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      20279402  273205      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      29144654  422381      0       0       0       0 
109: lxc575196045d62@if108: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 96:54:a4:81:dc:fe brd ff:ff:ff:ff:ff:ff link-netnsid 16 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       7043075   88205      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      29512416   59872      0       0       0       0 
111: lxc8ebc7c2aca63@if110: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 12:22:85:1c:4b:62 brd ff:ff:ff:ff:ff:ff link-netnsid 17 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       7051537   88335      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      29513833   59904      0       0       0       0 
113: lxc2eeff20b5f72@if112: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ee:ba:89:43:af:68 brd ff:ff:ff:ff:ff:ff link-netnsid 18 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       7054144   88367      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      29110125   59885      0       0       0       0 
115: lxc6690af65c315@if114: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 8e:95:28:05:34:b3 brd ff:ff:ff:ff:ff:ff link-netnsid 19 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       7051216   88339      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      29193702   59944      0       0       0       0 
117: lxc13a1d1f4e36f@if116: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 6e:23:00:d8:00:83 brd ff:ff:ff:ff:ff:ff link-netnsid 20 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       7051274   88339      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      29191667   59912      0       0       0       0 
119: lxc24279bc63cf7@if118: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 76:d4:f9:e7:80:c9 brd ff:ff:ff:ff:ff:ff link-netnsid 21 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       6991649   87421      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      29779724   59910      0       0       0       0 
121: lxc4572d400a690@if120: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether de:06:60:36:a8:68 brd ff:ff:ff:ff:ff:ff link-netnsid 22 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       6198322   75400      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      29780274   59890      0       0       0       0 
123: lxcf7380be6dd83@if122: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 6e:38:45:09:3b:5f brd ff:ff:ff:ff:ff:ff link-netnsid 23 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      20730378  210681      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      22838217  261882      0       0       0       0 
127: lxcc68174b20f8a@if126: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 9e:6b:51:ee:30:09 brd ff:ff:ff:ff:ff:ff link-netnsid 25 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      44922180  205411      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      61505689  184281      0       0       0       0 
129: lxcc2a40ff909ee@if128: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ae:8c:61:44:74:43 brd ff:ff:ff:ff:ff:ff link-netnsid 26 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 8 numrxqueues 8 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      63670916  429811      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
    1995866221  602548      0       0       0       0 
