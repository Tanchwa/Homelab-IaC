Endpoint ID: 4
Path: /sys/fs/bpf/tc/globals/cilium_policy_00004

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    0         0         0        
Allow    Egress      0          ANY          NONE         disabled    7048783   88291     0        


Endpoint ID: 82
Path: /sys/fs/bpf/tc/globals/cilium_policy_00082

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    0         0         0        
Allow    Egress      0          ANY          NONE         disabled    7045785   88262     0        


Endpoint ID: 107
Path: /sys/fs/bpf/tc/globals/cilium_policy_00107

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    16870583   233928    0        
Allow    Ingress     1          ANY          NONE         disabled    12269142   188383    0        
Allow    Egress      0          ANY          NONE         disabled    0          0         0        


Endpoint ID: 168
Path: /sys/fs/bpf/tc/globals/cilium_policy_00168

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES        PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    0            0         0        
Allow    Ingress     5202       6379/TCP     NONE         disabled    547132581    649664    24       
Allow    Ingress     35547      6379/TCP     NONE         disabled    4529100922   708200    24       
Allow    Ingress     35673      6379/TCP     NONE         disabled    30456859     416822    24       
Allow    Egress      0          53/TCP       NONE         disabled    0            0         24       
Allow    Egress      0          53/UDP       NONE         disabled    0            0         24       


Endpoint ID: 276
Path: /sys/fs/bpf/tc/globals/cilium_policy_00276

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    36521   241       0        


Endpoint ID: 355
Path: /sys/fs/bpf/tc/globals/cilium_policy_00355

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 428
Path: /sys/fs/bpf/tc/globals/cilium_policy_00428

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0          0         0        
Allow    Ingress     1          ANY          NONE         disabled    22784517   261783    0        
Allow    Egress      0          ANY          NONE         disabled    2326       28        0        


Endpoint ID: 453
Path: /sys/fs/bpf/tc/globals/cilium_policy_00453

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES       PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0           0         0        
Allow    Ingress     1          ANY          NONE         disabled    276622680   3155254   0        
Allow    Egress      0          ANY          NONE         disabled    67488665    419733    0        


Endpoint ID: 687
Path: /sys/fs/bpf/tc/globals/cilium_policy_00687

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0          0         0        
Allow    Ingress     1          ANY          NONE         disabled    17318296   196630    0        
Allow    Egress      0          ANY          NONE         disabled    40230060   259793    0        


Endpoint ID: 876
Path: /sys/fs/bpf/tc/globals/cilium_policy_00876

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    273614     450       0        
Allow    Ingress     1          ANY          NONE         disabled    30894977   279065    0        
Allow    Egress      0          ANY          NONE         disabled    89884784   1013210   0        


Endpoint ID: 1082
Path: /sys/fs/bpf/tc/globals/cilium_policy_01082

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    0         0         0        
Allow    Egress      0          ANY          NONE         disabled    6192654   75320     0        


Endpoint ID: 1236
Path: /sys/fs/bpf/tc/globals/cilium_policy_01236

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    0         0         0        
Allow    Egress      0          ANY          NONE         disabled    7046106   88258     0        


Endpoint ID: 1255
Path: /sys/fs/bpf/tc/globals/cilium_policy_01255

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    0         0         0        
Allow    Egress      0          ANY          NONE         disabled    6986288   87345     0        


Endpoint ID: 1369
Path: /sys/fs/bpf/tc/globals/cilium_policy_01369

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    41848703   146890    0        
Allow    Ingress     1          ANY          NONE         disabled    71463938   820402    0        
Allow    Egress      0          ANY          NONE         disabled    6997089    82836     0        


Endpoint ID: 1422
Path: /sys/fs/bpf/tc/globals/cilium_policy_01422

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    0         0         0        
Allow    Egress      0          ANY          NONE         disabled    7037644   88128     0        


Endpoint ID: 1432
Path: /sys/fs/bpf/tc/globals/cilium_policy_01432

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES       PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    101655396   1452633   0        
Allow    Ingress     1          ANY          NONE         disabled    58816584    682568    0        
Allow    Egress      0          ANY          NONE         disabled    152195589   2033180   0        


Endpoint ID: 1480
Path: /sys/fs/bpf/tc/globals/cilium_policy_01480

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    0         0         0        
Allow    Egress      0          ANY          NONE         disabled    7045913   88263     0        


Endpoint ID: 1783
Path: /sys/fs/bpf/tc/globals/cilium_policy_01783

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    3827175    19054     0        
Allow    Ingress     1          ANY          NONE         disabled    62565078   547346    0        
Allow    Egress      0          ANY          NONE         disabled    55237668   709408    0        


Endpoint ID: 2238
Path: /sys/fs/bpf/tc/globals/cilium_policy_02238

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    2606617    31327     0        
Allow    Ingress     1          ANY          NONE         disabled    0          0         0        
Allow    Egress      0          ANY          NONE         disabled    15397642   162437    0        


Endpoint ID: 2366
Path: /sys/fs/bpf/tc/globals/cilium_policy_02366

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0          0         0        
Allow    Ingress     1          ANY          NONE         disabled    0          0         0        
Allow    Egress      0          ANY          NONE         disabled    76342811   527101    0        


Endpoint ID: 2712
Path: /sys/fs/bpf/tc/globals/cilium_policy_02712

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 3028
Path: /sys/fs/bpf/tc/globals/cilium_policy_03028

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    206     2         0        


Endpoint ID: 3085
Path: /sys/fs/bpf/tc/globals/cilium_policy_03085

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    5237458   66059     0        
Allow    Ingress     1          ANY          NONE         disabled    7437094   84947     0        
Allow    Egress      0          ANY          NONE         disabled    0         0         0        


Endpoint ID: 3245
Path: /sys/fs/bpf/tc/globals/cilium_policy_03245

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1094       5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     2955       5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     3360       5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     3647       5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     3714       5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     4226       5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     4327       5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     5202       5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     6608       5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     8745       5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     8786       5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     9538       5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     11923      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     14195      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     18542      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     18891      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     22426      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     24759      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     34237      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     34495      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     35547      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     35673      5557/TCP     NONE         disabled    0         0         24       
Allow    Ingress     35673      5556/TCP     NONE         disabled    0         0         24       
Allow    Ingress     35673      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     40771      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     44101      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     48390      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     50982      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     51610      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     56903      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     58805      5558/TCP     NONE         disabled    0         0         24       
Allow    Ingress     59194      5558/TCP     NONE         disabled    0         0         24       
Allow    Egress      0          ANY          NONE         disabled    4392531   51268     0        


Endpoint ID: 3748
Path: /sys/fs/bpf/tc/globals/cilium_policy_03748

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    0          0         0        
Allow    Ingress     1094       8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     1094       7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     2955       8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     2955       7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     3360       7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     3360       8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     3647       7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     3647       8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     3714       7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     3714       8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     4226       7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     4226       8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     4327       7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     4327       8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     5202       7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     5202       8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     6608       7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     6608       8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     8745       8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     8745       7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     8786       7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     8786       8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     9538       8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     9538       7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     11923      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     11923      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     14195      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     14195      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     18542      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     18542      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     18891      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     18891      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     22426      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     22426      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     24759      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     24759      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     34237      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     34237      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     34495      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     34495      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     35547      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     35547      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     35673      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     35673      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     40771      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     40771      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     44101      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     44101      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     48390      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     48390      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     50982      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     50982      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     51610      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     51610      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     56903      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     56903      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     58805      7000/TCP     NONE         disabled    0          0         24       
Allow    Ingress     58805      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     59194      8080/TCP     NONE         disabled    0          0         24       
Allow    Ingress     59194      7000/TCP     NONE         disabled    0          0         24       
Allow    Egress      0          ANY          NONE         disabled    19560142   239393    0        


Endpoint ID: 3865
Path: /sys/fs/bpf/tc/globals/cilium_policy_03865

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES       PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1842446     4595      0        
Allow    Ingress     1          ANY          NONE         disabled    118109278   1359520   0        
Allow    Egress      0          ANY          NONE         disabled    670956409   6328571   0        


