filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc7a863e00b5ab direct-action not_in_hw id 12327 tag c12569606d259998 jited 
