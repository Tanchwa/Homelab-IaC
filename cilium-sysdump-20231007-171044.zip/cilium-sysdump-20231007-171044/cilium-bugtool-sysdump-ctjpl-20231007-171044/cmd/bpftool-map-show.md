1: hash  flags 0x0
	key 9B  value 1B  max_entries 500  memlock 8192B
2: hash  flags 0x0
	key 9B  value 1B  max_entries 500  memlock 8192B
48: hash  name cilium_auth_map  flags 0x1
	key 12B  value 8B  max_entries 524288  memlock 12582912B
49: array  name cilium_runtime_  flags 0x0
	key 4B  value 8B  max_entries 256  memlock 4096B
50: perf_event_array  name cilium_signals  flags 0x0
	key 4B  value 4B  max_entries 8  memlock 4096B
51: hash  name cilium_node_map  flags 0x1
	key 20B  value 2B  max_entries 16384  memlock 393216B
52: perf_event_array  name cilium_events  flags 0x0
	key 4B  value 4B  max_entries 8  memlock 4096B
53: hash  name cilium_lxc  flags 0x1
	key 20B  value 48B  max_entries 65535  memlock 4718592B
55: percpu_hash  name cilium_metrics  flags 0x1
	key 8B  value 16B  max_entries 1024  memlock 139264B
57: hash  name cilium_lb4_serv  flags 0x1
	key 12B  value 12B  max_entries 65536  memlock 1572864B
58: hash  name cilium_lb4_back  flags 0x1
	key 4B  value 12B  max_entries 65536  memlock 1048576B
59: hash  name cilium_lb4_reve  flags 0x1
	key 2B  value 6B  max_entries 65536  memlock 524288B
60: prog_array  name cilium_call_pol  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524288B
	owner_prog_type sched_cls  owner jited
61: lru_hash  name cilium_ct4_glob  flags 0x0
	key 14B  value 56B  max_entries 131072  memlock 9437184B
62: lru_hash  name cilium_ct_any4_  flags 0x0
	key 14B  value 56B  max_entries 65536  memlock 4718592B
63: lru_hash  name cilium_ipv4_fra  flags 0x0
	key 12B  value 4B  max_entries 8192  memlock 131072B
66: hash  name cilium_l2_respo  flags 0x1
	key 8B  value 8B  max_entries 4096  memlock 65536B
	btf_id 145
67: prog_array  name cilium_calls_ov  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
68: array  name cilium_encrypt_  flags 0x0
	key 4B  value 1B  max_entries 1  memlock 4096B
	btf_id 146
69: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
71: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
74: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
203: lru_hash  name cilium_lb4_reve  flags 0x0
	key 16B  value 8B  max_entries 65536  memlock 1572864B
205: lru_hash  name cilium_nodeport  flags 0x0
	key 4B  value 8B  max_entries 131072  memlock 2097152B
218: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
329: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
331: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
754: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 20480000B
755: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 2621440B
762: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 2921
1168: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
1169: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
1171: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
1172: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
1176: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 5332
1177: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 5343
1178: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
1179: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 5354
1180: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
1186: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
1187: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 5366
1188: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
1192: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
1193: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 5377
1194: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
1203: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
1204: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
1205: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 5399
1215: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
1216: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 5421
1217: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
1385: lru_hash  name cilium_snat_v4_  flags 0x0
	key 14B  value 40B  max_entries 131072  memlock 7340032B
1386: hash  name cilium_lb_affin  flags 0x1
	key 8B  value 1B  max_entries 65536  memlock 1048576B
1387: lru_hash  name cilium_lb4_affi  flags 0x0
	key 16B  value 16B  max_entries 65536  memlock 2097152B
1388: lpm_trie  name cilium_lb4_sour  flags 0x1
	key 12B  value 1B  max_entries 65536  memlock 1048576B
1954: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 20480000B
1955: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 2621440B
1957: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6494
1959: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6516
1960: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6527
1961: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6538
1962: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6549
1963: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6560
1964: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6571
1965: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6582
1966: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
1967: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
1968: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6593
1976: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
1977: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
1981: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6675
1990: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
1991: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
1992: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6708
1993: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
1994: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
1995: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
1996: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6719
1998: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6730
1999: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2005: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2006: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6741
2007: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2009: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2010: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6752
2011: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2015: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2016: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6763
2017: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2018: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2019: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6774
2020: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2023: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2024: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6785
2025: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2027: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2028: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6796
2029: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2030: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2031: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6807
2032: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2033: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2034: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2035: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6818
2036: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2037: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2038: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6829
2040: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2041: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6840
2042: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2063: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2064: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2065: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6862
2066: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2067: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2068: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 6864
4137: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 20480000B
4138: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 2621440B
