filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc8ebc7c2aca63 direct-action not_in_hw id 12639 tag 0628de34bb4a83d9 jited 
