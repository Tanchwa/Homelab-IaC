qdisc noqueue 0: dev lo root refcnt 2 
qdisc fq_codel 0: dev enp0s25 root refcnt 2 limit 10240p flows 1024 quantum 1514 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev enp0s25 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxc4c3047597631 root refcnt 2 
qdisc clsact ffff: dev lxc4c3047597631 parent ffff:fff1 
qdisc noqueue 0: dev lxc7a863e00b5ab root refcnt 2 
qdisc clsact ffff: dev lxc7a863e00b5ab parent ffff:fff1 
qdisc noqueue 0: dev lxcfb97f3359139 root refcnt 2 
qdisc clsact ffff: dev lxcfb97f3359139 parent ffff:fff1 
qdisc noqueue 0: dev lxc6b34683b4c68 root refcnt 2 
qdisc clsact ffff: dev lxc6b34683b4c68 parent ffff:fff1 
qdisc noqueue 0: dev lxc0666b0e76f82 root refcnt 2 
qdisc clsact ffff: dev lxc0666b0e76f82 parent ffff:fff1 
qdisc noqueue 0: dev lxc0813f578bd6f root refcnt 2 
qdisc clsact ffff: dev lxc0813f578bd6f parent ffff:fff1 
qdisc noqueue 0: dev lxca1ac2634066e root refcnt 2 
qdisc clsact ffff: dev lxca1ac2634066e parent ffff:fff1 
qdisc noqueue 0: dev lxc635980f3a45f root refcnt 2 
qdisc clsact ffff: dev lxc635980f3a45f parent ffff:fff1 
qdisc noqueue 0: dev lxc2e76a7ee6054 root refcnt 2 
qdisc clsact ffff: dev lxc2e76a7ee6054 parent ffff:fff1 
qdisc noqueue 0: dev lxcd5a3fea4fb9e root refcnt 2 
qdisc clsact ffff: dev lxcd5a3fea4fb9e parent ffff:fff1 
qdisc noqueue 0: dev lxcaae3e7a2fe30 root refcnt 2 
qdisc clsact ffff: dev lxcaae3e7a2fe30 parent ffff:fff1 
qdisc noqueue 0: dev lxc1f718abe12f5 root refcnt 2 
qdisc clsact ffff: dev lxc1f718abe12f5 parent ffff:fff1 
qdisc noqueue 0: dev lxc1a13fe9d3eba root refcnt 2 
qdisc clsact ffff: dev lxc1a13fe9d3eba parent ffff:fff1 
qdisc noqueue 0: dev lxcf39b2c9b8b13 root refcnt 2 
qdisc clsact ffff: dev lxcf39b2c9b8b13 parent ffff:fff1 
qdisc noqueue 0: dev lxc575196045d62 root refcnt 2 
qdisc clsact ffff: dev lxc575196045d62 parent ffff:fff1 
qdisc noqueue 0: dev lxc8ebc7c2aca63 root refcnt 2 
qdisc clsact ffff: dev lxc8ebc7c2aca63 parent ffff:fff1 
qdisc noqueue 0: dev lxc2eeff20b5f72 root refcnt 2 
qdisc clsact ffff: dev lxc2eeff20b5f72 parent ffff:fff1 
qdisc noqueue 0: dev lxc6690af65c315 root refcnt 2 
qdisc clsact ffff: dev lxc6690af65c315 parent ffff:fff1 
qdisc noqueue 0: dev lxc13a1d1f4e36f root refcnt 2 
qdisc clsact ffff: dev lxc13a1d1f4e36f parent ffff:fff1 
qdisc noqueue 0: dev lxc24279bc63cf7 root refcnt 2 
qdisc clsact ffff: dev lxc24279bc63cf7 parent ffff:fff1 
qdisc noqueue 0: dev lxc4572d400a690 root refcnt 2 
qdisc clsact ffff: dev lxc4572d400a690 parent ffff:fff1 
qdisc noqueue 0: dev lxcf7380be6dd83 root refcnt 2 
qdisc clsact ffff: dev lxcf7380be6dd83 parent ffff:fff1 
qdisc noqueue 0: dev lxcc68174b20f8a root refcnt 2 
qdisc clsact ffff: dev lxcc68174b20f8a parent ffff:fff1 
qdisc noqueue 0: dev lxcc2a40ff909ee root refcnt 2 
qdisc clsact ffff: dev lxcc2a40ff909ee parent ffff:fff1 
