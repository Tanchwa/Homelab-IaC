192.168.1.3 dev enp0s25 lladdr c2:a5:11:ab:b5:26 STALE
192.168.1.1 dev enp0s25 lladdr 40:5d:82:d6:05:18 STALE
192.168.1.15 dev enp0s25 lladdr dc:41:a9:1f:5b:53 STALE
192.168.1.31 dev enp0s25 lladdr f4:8e:38:82:a9:dc REACHABLE
