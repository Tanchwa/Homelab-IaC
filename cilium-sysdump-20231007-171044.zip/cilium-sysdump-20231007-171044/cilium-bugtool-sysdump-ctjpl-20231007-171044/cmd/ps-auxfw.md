USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root          18  0.0  0.1 722976 13040 ?        Ssl  17:11   0:00 cilium-bugtool --archiveType=gz
root          31  0.0  0.0   7060  1580 ?        R    17:11   0:00  \_ ps auxfw
root          34  0.0  0.1 722976 13040 ?        R    17:11   0:00  \_ cilium-bugtool --archiveType=gz
root           1  0.1  0.0   2788  1004 ?        Ss   17:11   0:00 /bin/sleep 1d
