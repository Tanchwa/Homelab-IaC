filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc2e76a7ee6054 direct-action not_in_hw id 12445 tag 7beddb94c2b16854 jited 
