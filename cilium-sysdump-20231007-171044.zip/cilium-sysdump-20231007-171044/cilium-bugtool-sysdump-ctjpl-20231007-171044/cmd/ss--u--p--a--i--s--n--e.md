Total: 414
TCP:   233 (estab 11, closed 213, orphaned 0, timewait 105)

Transport Total     IP        IPv6
RAW	  1         0         1        
UDP	  4         3         1        
TCP	  20        11        9        
INET	  25        14        11       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q       Local Address:Port Peer Address:PortProcess                                                    
UNCONN 0      0            127.0.0.53%lo:53        0.0.0.0:*    uid:102 ino:31377 sk:e8e cgroup:unreachable:13f2 <->      
UNCONN 0      0      192.168.1.4%enp0s25:68        0.0.0.0:*    uid:101 ino:15360274 sk:4b8ea2 cgroup:unreachable:1390 <->
UNCONN 0      0                  0.0.0.0:8472      0.0.0.0:*    ino:75084 sk:4b8ea3 cgroup:unreachable:2677 <->           
UNCONN 0      0                     [::]:8472         [::]:*    ino:75083 sk:4b8ea5 cgroup:unreachable:2677 v6only:1 <->  
