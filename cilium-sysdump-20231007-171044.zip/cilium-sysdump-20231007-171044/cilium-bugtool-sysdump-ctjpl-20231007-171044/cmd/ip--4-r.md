default via 192.168.1.1 dev enp0s25 proto dhcp src 192.168.1.4 metric 100 
10.0.0.0/24 via 10.0.1.245 dev cilium_host proto kernel src 10.0.1.245 mtu 1450 
10.0.1.0/24 via 10.0.1.245 dev cilium_host proto kernel src 10.0.1.245 
10.0.1.245 dev cilium_host proto kernel scope link 
192.168.1.0/24 dev enp0s25 proto kernel scope link src 192.168.1.4 metric 100 
192.168.1.1 dev enp0s25 proto dhcp scope link src 192.168.1.4 metric 100 
