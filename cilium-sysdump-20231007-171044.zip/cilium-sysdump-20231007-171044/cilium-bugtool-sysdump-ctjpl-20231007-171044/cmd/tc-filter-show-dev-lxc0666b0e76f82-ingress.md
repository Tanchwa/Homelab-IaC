filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc0666b0e76f82 direct-action not_in_hw id 12356 tag 1746141b8ccf31fd jited 
