Module                  Size  Used by
udp_diag               16384  0
tcp_diag               16384  0
inet_diag              24576  2 tcp_diag,udp_diag
cpuid                  16384  0
xt_statistic           16384  4
ip6t_REJECT            16384  0
nf_reject_ipv6         20480  1 ip6t_REJECT
xt_hl                  16384  0
ip6t_rt                20480  0
xt_LOG                 20480  0
nf_log_syslog          20480  0
nft_limit              16384  0
xt_limit               16384  0
nf_conntrack_netlink    49152  0
xt_TPROXY              20480  2
nf_tproxy_ipv6         20480  1 xt_TPROXY
nf_tproxy_ipv4         20480  1 xt_TPROXY
xt_CT                  16384  5
cls_bpf                24576  31
sch_ingress            16384  28
vxlan                  86016  0
ip6_udp_tunnel         16384  1 vxlan
udp_tunnel             20480  1 vxlan
xfrm_user              40960  0
xfrm_algo              16384  1 xfrm_user
veth                   32768  0
xt_socket              16384  1
nf_socket_ipv4         16384  1 xt_socket
nf_socket_ipv6         20480  1 xt_socket
ip6table_filter        16384  0
ip6table_raw           16384  0
ip6table_mangle        16384  0
ip6_tables             32768  3 ip6table_filter,ip6table_raw,ip6table_mangle
iptable_filter         16384  0
iptable_raw            16384  0
iptable_mangle         16384  0
iptable_nat            16384  0
xt_recent              24576  0
xt_addrtype            16384  2
xt_nat                 16384  34
ipt_REJECT             16384  1
nf_reject_ipv4         16384  1 ipt_REJECT
xt_tcpudp              20480  88
ip_set                 53248  0
ip_vs_sh               16384  0
ip_vs_wrr              16384  0
ip_vs_rr               16384  0
ip_vs                 176128  6 ip_vs_rr,ip_vs_sh,ip_vs_wrr
xt_MASQUERADE          20480  3
nft_chain_nat          16384  6
nf_nat                 49152  4 xt_nat,nft_chain_nat,iptable_nat,xt_MASQUERADE
xt_mark                16384  14
xt_conntrack           16384  20
nf_conntrack          172032  7 xt_conntrack,nf_nat,xt_nat,nf_conntrack_netlink,xt_CT,xt_MASQUERADE,ip_vs
nf_defrag_ipv6         24576  4 nf_conntrack,xt_socket,xt_TPROXY,ip_vs
nf_defrag_ipv4         16384  3 nf_conntrack,xt_socket,xt_TPROXY
xt_comment             16384  218
nft_compat             20480  392
nft_counter            16384  268
nf_tables             249856  712 nft_compat,nft_counter,nft_chain_nat,nft_limit
nfnetlink              20480  4 nft_compat,nf_conntrack_netlink,nf_tables,ip_set
br_netfilter           32768  0
bridge                307200  1 br_netfilter
stp                    16384  1 bridge
llc                    16384  2 bridge,stp
overlay               151552  60
tls                   114688  4
cdc_acm                40960  0
binfmt_misc            24576  1
snd_hda_codec_analog    20480  1
snd_hda_codec_generic   102400  1 snd_hda_codec_analog
snd_hda_intel          53248  0
snd_intel_dspcfg       28672  1 snd_hda_intel
snd_intel_sdw_acpi     20480  1 snd_intel_dspcfg
coretemp               24576  0
snd_hda_codec         163840  3 snd_hda_codec_generic,snd_hda_intel,snd_hda_codec_analog
snd_hda_core          110592  4 snd_hda_codec_generic,snd_hda_intel,snd_hda_codec_analog,snd_hda_codec
ppdev                  24576  0
dell_wmi               24576  0
ledtrig_audio          16384  2 snd_hda_codec_generic,dell_wmi
dell_smbios            28672  1 dell_wmi
kvm_intel             368640  0
snd_hwdep              16384  1 snd_hda_codec
dcdbas                 20480  1 dell_smbios
kvm                  1032192  1 kvm_intel
joydev                 32768  0
wmi_bmof               16384  0
input_leds             16384  0
snd_pcm               143360  3 snd_hda_intel,snd_hda_codec,snd_hda_core
sparse_keymap          16384  1 dell_wmi
dell_wmi_descriptor    20480  2 dell_wmi,dell_smbios
serio_raw              20480  0
parport_pc             49152  0
at24                   24576  0
snd_timer              40960  1 snd_pcm
parport                69632  2 parport_pc,ppdev
mac_hid                16384  0
mei_me                 40960  0
mei                   135168  1 mei_me
snd                   106496  7 snd_hda_codec_generic,snd_hwdep,snd_hda_intel,snd_hda_codec_analog,snd_hda_codec,snd_timer,snd_pcm
soundcore              16384  1 snd
sch_fq_codel           20480  2
dm_multipath           40960  0
scsi_dh_rdac           20480  0
scsi_dh_emc            16384  0
msr                    16384  0
ramoops                32768  0
pstore_blk             16384  0
scsi_dh_alua           20480  0
pstore_zone            32768  1 pstore_blk
reed_solomon           28672  1 ramoops
efi_pstore             16384  0
ip_tables              32768  4 iptable_filter,iptable_raw,iptable_nat,iptable_mangle
x_tables               53248  28 ip6table_filter,xt_conntrack,xt_statistic,ip6table_raw,iptable_filter,nft_compat,xt_LOG,xt_socket,xt_tcpudp,xt_addrtype,xt_recent,xt_nat,ip6t_rt,xt_comment,ip6_tables,xt_TPROXY,ipt_REJECT,xt_CT,iptable_raw,ip_tables,iptable_nat,xt_limit,xt_hl,ip6table_mangle,xt_MASQUERADE,ip6t_REJECT,iptable_mangle,xt_mark
autofs4                49152  2
btrfs                1560576  0
blake2b_generic        20480  0
zstd_compress         229376  1 btrfs
raid10                 69632  0
raid456               163840  0
async_raid6_recov      24576  1 raid456
async_memcpy           20480  2 raid456,async_raid6_recov
async_pq               24576  2 raid456,async_raid6_recov
async_xor              20480  3 async_pq,raid456,async_raid6_recov
async_tx               20480  5 async_pq,async_memcpy,async_xor,raid456,async_raid6_recov
xor                    24576  2 async_xor,btrfs
raid6_pq              122880  4 async_pq,btrfs,raid456,async_raid6_recov
libcrc32c              16384  6 nf_conntrack,nf_nat,btrfs,nf_tables,raid456,ip_vs
raid1                  49152  0
raid0                  24576  0
multipath              20480  0
linear                 20480  0
i915                 3117056  1
hid_generic            16384  0
i2c_algo_bit           16384  1 i915
ttm                    86016  1 i915
drm_kms_helper        311296  1 i915
syscopyarea            16384  1 drm_kms_helper
sysfillrect            20480  1 drm_kms_helper
usbhid                 65536  0
sysimgblt              16384  1 drm_kms_helper
fb_sys_fops            16384  1 drm_kms_helper
gpio_ich               16384  0
cec                    61440  2 drm_kms_helper,i915
rc_core                65536  1 cec
i2c_i801               36864  0
drm                   622592  4 drm_kms_helper,i915,ttm
psmouse               176128  0
i2c_smbus              20480  1 i2c_i801
lpc_ich                28672  0
hid                   151552  2 usbhid,hid_generic
e1000e                299008  0
video                  65536  2 dell_wmi,i915
pata_acpi              16384  0
wmi                    32768  4 dell_wmi,wmi_bmof,dell_smbios,dell_wmi_descriptor
