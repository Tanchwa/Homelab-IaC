top - 17:11:31 up 8 days, 18:30,  0 users,  load average: 0.24, 0.22, 0.40
Tasks:   4 total,   2 running,   2 sleeping,   0 stopped,   0 zombie
%Cpu(s): 25.8 us, 32.3 sy,  0.0 ni, 32.3 id,  3.2 wa,  0.0 hi,  6.5 si,  0.0 st
MiB Mem :   9776.7 total,    477.1 free,   1770.4 used,   7529.2 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   7651.7 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
     48 root      20   0    3100   1832   1500 R  73.3   0.0   0:00.11 sysctl
      1 root      20   0    2788   1004    916 S   0.0   0.0   0:00.01 sleep
     18 root      20   0  722976  13332   9664 S   0.0   0.1   0:00.02 cilium-+
     45 root      20   0    7180   2904   2576 R   0.0   0.0   0:00.00 top
