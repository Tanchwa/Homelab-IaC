key: 01 00 00 00  value: e4 2f 00 00
key: 07 00 00 00  value: e8 2f 00 00
key: 0f 00 00 00  value: e6 2f 00 00
key: 11 00 00 00  value: e7 2f 00 00
key: 24 00 00 00  value: e5 2f 00 00
key: 26 00 00 00  value: eb 2f 00 00
Found 6 elements
