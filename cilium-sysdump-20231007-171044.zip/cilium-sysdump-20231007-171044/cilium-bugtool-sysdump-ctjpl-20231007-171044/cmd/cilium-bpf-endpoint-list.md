IP ADDRESS      LOCAL ENDPOINT INFO
10.0.1.53:0     id=687   sec_id=58805 flags=0x0000 ifindex=129 mac=BE:F0:E0:B3:A3:0E nodemac=AE:8C:61:44:74:43   
10.0.1.52:0     id=876   sec_id=1094  flags=0x0000 ifindex=101 mac=76:0F:F6:2F:AA:CA nodemac=EE:48:75:CE:62:8D   
10.0.1.87:0     id=1422  sec_id=3360  flags=0x0000 ifindex=109 mac=F2:38:85:57:5C:AA nodemac=96:54:A4:81:DC:FE   
10.0.1.79:0     id=453   sec_id=14195 flags=0x0000 ifindex=95  mac=BA:77:41:78:94:66 nodemac=8A:27:E0:F5:97:31   
10.0.1.51:0     id=168   sec_id=44101 flags=0x0000 ifindex=57  mac=3A:6B:A3:2D:22:C0 nodemac=0E:B8:AA:DE:9D:FA   
10.0.1.82:0     id=276   sec_id=8786  flags=0x0000 ifindex=103 mac=0E:64:05:16:D2:73 nodemac=E6:B1:56:36:7D:6D   
10.0.1.1:0      id=2238  sec_id=24759 flags=0x0000 ifindex=127 mac=EE:3D:15:DA:A9:C0 nodemac=9E:6B:51:EE:30:09   
10.0.1.239:0    id=428   sec_id=22426 flags=0x0000 ifindex=123 mac=BA:F3:73:93:43:7B nodemac=6E:38:45:09:3B:5F   
10.0.1.207:0    id=1082  sec_id=48390 flags=0x0000 ifindex=121 mac=66:E8:1F:61:08:86 nodemac=DE:06:60:36:A8:68   
10.0.1.158:0    id=1369  sec_id=9538  flags=0x0000 ifindex=35  mac=8E:42:A7:CF:27:7E nodemac=FE:30:6C:94:FE:76   
10.0.1.245:0    (localhost)                                                                                      
10.0.1.179:0    id=3085  sec_id=4     flags=0x0000 ifindex=93  mac=02:70:CB:09:21:4A nodemac=22:43:54:CF:3E:55   
192.168.1.4:0   (localhost)                                                                                      
10.0.1.236:0    id=107   sec_id=34237 flags=0x0000 ifindex=107 mac=26:70:60:CE:37:B2 nodemac=22:FE:ED:BF:DD:93   
10.0.1.105:0    id=3245  sec_id=18542 flags=0x0000 ifindex=55  mac=F6:B1:F2:28:2C:1F nodemac=DA:C8:3E:E7:73:71   
10.0.1.20:0     id=82    sec_id=11923 flags=0x0000 ifindex=115 mac=86:6E:4F:70:DE:8B nodemac=8E:95:28:05:34:B3   
10.0.1.29:0     id=3865  sec_id=3647  flags=0x0000 ifindex=67  mac=CE:7C:F1:90:DA:31 nodemac=42:B4:AE:4B:76:E1   
10.0.1.195:0    id=2712  sec_id=2955  flags=0x0000 ifindex=105 mac=C2:96:1F:87:8A:BF nodemac=66:6F:E3:FC:FC:5D   
10.0.1.100:0    id=4     sec_id=3714  flags=0x0000 ifindex=113 mac=F6:90:F9:62:97:4C nodemac=EE:BA:89:43:AF:68   
10.0.1.119:0    id=1255  sec_id=48390 flags=0x0000 ifindex=119 mac=EA:B7:16:1F:B6:63 nodemac=76:D4:F9:E7:80:C9   
10.0.1.134:0    id=3028  sec_id=6608  flags=0x0000 ifindex=99  mac=22:8D:51:4F:45:D8 nodemac=4E:F3:36:C9:E2:B3   
10.0.1.208:0    id=3748  sec_id=50982 flags=0x0000 ifindex=61  mac=5A:EB:C1:6A:0C:49 nodemac=96:95:85:C3:95:0A   
10.0.1.26:0     id=1236  sec_id=3360  flags=0x0000 ifindex=111 mac=96:B1:C4:E4:22:4F nodemac=12:22:85:1C:4B:62   
10.0.1.106:0    id=1432  sec_id=59194 flags=0x0000 ifindex=63  mac=06:A9:87:19:DE:A0 nodemac=D2:8C:DC:38:32:B1   
10.0.1.230:0    id=1480  sec_id=11923 flags=0x0000 ifindex=117 mac=C6:BA:13:F4:17:28 nodemac=6E:23:00:D8:00:83   
10.0.1.73:0     id=1783  sec_id=35673 flags=0x0000 ifindex=59  mac=66:AB:1C:B8:DC:E0 nodemac=AA:66:00:2F:BC:A7   
10.0.1.162:0    id=2366  sec_id=4327  flags=0x0000 ifindex=71  mac=9A:8F:70:21:96:BA nodemac=1E:92:FE:FE:94:B3   
