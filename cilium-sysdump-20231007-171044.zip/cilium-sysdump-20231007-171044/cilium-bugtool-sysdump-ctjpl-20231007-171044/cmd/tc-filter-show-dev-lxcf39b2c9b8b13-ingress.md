filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxcf39b2c9b8b13 direct-action not_in_hw id 12610 tag baaee14407a4fe5d jited 
