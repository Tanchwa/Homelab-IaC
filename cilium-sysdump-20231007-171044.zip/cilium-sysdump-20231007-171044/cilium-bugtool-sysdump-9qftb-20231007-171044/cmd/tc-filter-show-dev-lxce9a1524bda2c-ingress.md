filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxce9a1524bda2c direct-action not_in_hw id 26612 tag f7027c2b9e8c3c1c jited 
