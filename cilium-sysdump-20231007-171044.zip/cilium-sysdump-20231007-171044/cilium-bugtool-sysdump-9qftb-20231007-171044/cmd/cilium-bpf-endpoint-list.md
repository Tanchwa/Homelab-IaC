IP ADDRESS       LOCAL ENDPOINT INFO
10.0.0.237:0     id=1221  sec_id=3714  flags=0x0000 ifindex=105 mac=2A:A3:83:7D:E8:D2 nodemac=B2:94:E0:9C:D2:D6   
10.0.0.106:0     id=595   sec_id=4     flags=0x0000 ifindex=117 mac=12:E2:6F:00:F0:81 nodemac=BE:FC:33:2D:EB:44   
10.0.0.92:0      id=3403  sec_id=11923 flags=0x0000 ifindex=107 mac=02:59:5E:7F:C7:FF nodemac=A2:8A:39:DB:EE:6D   
10.0.0.212:0     id=2533  sec_id=8745  flags=0x0000 ifindex=115 mac=EE:32:26:09:72:35 nodemac=D6:3A:5A:96:FE:CE   
10.0.0.172:0     id=914   sec_id=2955  flags=0x0000 ifindex=95  mac=06:3F:F3:BF:C0:6C nodemac=B2:C2:AE:0C:EE:0C   
192.168.1.31:0   (localhost)                                                                                      
10.0.0.225:0     id=66    sec_id=6608  flags=0x0000 ifindex=91  mac=B6:E3:85:C4:9F:39 nodemac=EE:52:35:63:C2:FE   
10.0.0.91:0      (localhost)                                                                                      
10.0.0.40:0      id=2647  sec_id=34495 flags=0x0000 ifindex=93  mac=02:30:27:89:17:14 nodemac=4E:25:D3:9C:24:F2   
10.0.0.140:0     id=323   sec_id=51610 flags=0x0000 ifindex=53  mac=52:C5:9A:86:61:28 nodemac=4A:9C:85:C3:1E:21   
10.0.0.30:0      id=684   sec_id=4226  flags=0x0000 ifindex=63  mac=F2:0D:CB:02:4E:E9 nodemac=D6:71:B2:FC:5A:C4   
10.0.0.57:0      id=508   sec_id=35547 flags=0x0000 ifindex=45  mac=9E:23:F2:76:D4:B9 nodemac=06:A1:3A:89:56:DC   
10.0.0.1:0       id=699   sec_id=48390 flags=0x0000 ifindex=109 mac=42:E4:55:08:62:B6 nodemac=E6:14:5B:DC:4E:03   
10.0.0.168:0     id=1124  sec_id=3714  flags=0x0000 ifindex=103 mac=E2:AF:51:EE:CE:E4 nodemac=4A:27:3B:9A:56:AE   
10.0.0.238:0     id=2104  sec_id=56903 flags=0x0000 ifindex=39  mac=56:D5:9F:6F:D8:3F nodemac=8E:B8:1C:FE:BD:8F   
10.0.0.56:0      id=757   sec_id=1094  flags=0x0000 ifindex=89  mac=F2:84:34:3E:A6:77 nodemac=8A:2B:44:BB:C7:69   
10.0.0.54:0      id=292   sec_id=3360  flags=0x0000 ifindex=101 mac=B2:20:3B:B4:2E:80 nodemac=9E:36:2A:53:0F:58   
10.0.0.178:0     id=68    sec_id=22426 flags=0x0000 ifindex=111 mac=52:A3:C0:99:E3:8F nodemac=D2:6F:54:63:72:3B   
10.0.0.98:0      id=1224  sec_id=9538  flags=0x0000 ifindex=31  mac=FE:2C:12:3B:15:B9 nodemac=72:83:12:80:DE:95   
10.0.0.185:0     id=139   sec_id=5202  flags=0x0000 ifindex=43  mac=A6:B3:64:3A:69:BC nodemac=EE:5F:57:B2:4F:49   
10.0.0.174:0     id=1804  sec_id=40771 flags=0x0000 ifindex=65  mac=36:D0:52:93:E6:E0 nodemac=D6:41:84:83:A2:21   
