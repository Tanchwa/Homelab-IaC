xdp:

tc:
enp0s31f6(2) clsact/ingress cil_from_netdev-enp0s31f6 id 26579
enp0s31f6(2) clsact/egress cil_to_netdev-enp0s31f6 id 26587
cilium_net(3) clsact/ingress cil_to_host-cilium_net id 26539
cilium_host(4) clsact/ingress cil_to_host-cilium_host id 26477
cilium_host(4) clsact/egress cil_from_host-cilium_host id 26498
cilium_vxlan(5) clsact/ingress cil_from_overlay-cilium_vxlan id 26422
cilium_vxlan(5) clsact/egress cil_to_overlay-cilium_vxlan id 26423
lxce603f37ea079(31) clsact/ingress cil_from_container-lxce603f37ea079 id 26622
lxc45f7788338a8(39) clsact/ingress cil_from_container-lxc45f7788338a8 id 26433
lxc434d9886f6d8(43) clsact/ingress cil_from_container-lxc434d9886f6d8 id 26648
lxcc339546cf8ed(45) clsact/ingress cil_from_container-lxcc339546cf8ed id 26545
lxcd64119894239(53) clsact/ingress cil_from_container-lxcd64119894239 id 26471
lxc3977a6270e7a(63) clsact/ingress cil_from_container-lxc3977a6270e7a id 26439
lxc6382deee4ab8(65) clsact/ingress cil_from_container-lxc6382deee4ab8 id 26661
lxc22ea99fdaed2(89) clsact/ingress cil_from_container-lxc22ea99fdaed2 id 26642
lxc94dec6699d0f(91) clsact/ingress cil_from_container-lxc94dec6699d0f id 26609
lxcd8716ad68b0f(93) clsact/ingress cil_from_container-lxcd8716ad68b0f id 26484
lxc209553264675(95) clsact/ingress cil_from_container-lxc209553264675 id 26571
lxc5cddd0950c5b(101) clsact/ingress cil_from_container-lxc5cddd0950c5b id 26534
lxc238d768b97ae(103) clsact/ingress cil_from_container-lxc238d768b97ae id 26520
lxc8d1805c87601(105) clsact/ingress cil_from_container-lxc8d1805c87601 id 26599
lxc09c47b13f40c(107) clsact/ingress cil_from_container-lxc09c47b13f40c id 26429
lxcd440d5ca922b(109) clsact/ingress cil_from_container-lxcd440d5ca922b id 26528
lxcdbe084283d2d(111) clsact/ingress cil_from_container-lxcdbe084283d2d id 26493
lxce9a1524bda2c(115) clsact/ingress cil_from_container-lxce9a1524bda2c id 26612

flow_dissector:

