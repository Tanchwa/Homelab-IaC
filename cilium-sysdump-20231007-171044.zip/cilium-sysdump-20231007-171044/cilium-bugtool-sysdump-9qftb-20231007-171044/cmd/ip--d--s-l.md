1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00 promiscuity 0 minmtu 0 maxmtu 0 addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:   bytes   packets errors dropped  missed   mcast           
    38474274975 190794755      0       0       0       0 
    TX:   bytes   packets errors dropped carrier collsns           
    38474274975 190794755      0       0       0       0 
2: enp0s31f6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP mode DEFAULT group default qlen 1000
    link/ether f4:8e:38:82:a9:dc brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 9000 addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 parentbus pci parentdev 0000:00:1f.6 
    RX:   bytes  packets errors dropped  missed   mcast           
    10639368642 21026187      0     782       0  380607 
    TX:   bytes  packets errors dropped carrier collsns           
    20448201499 24420584      0       0       0       0 
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 6a:1b:03:db:72:c8 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
         51890     795      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
       5858976   71027      0       0       0       0 
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 1e:82:1b:84:22:ae brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       5858976   71027      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
         51890     795      0       0       0       0 
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UNKNOWN mode DEFAULT group default qlen 1000
    link/ether 0a:7c:84:bb:ae:85 brd ff:ff:ff:ff:ff:ff promiscuity 0 minmtu 68 maxmtu 65535 
    vxlan external id 0 srcport 0 0 dstport 8472 nolearning ttl auto ageing 300 udpcsum noudp6zerocsumtx noudp6zerocsumrx addrgenmode eui64 numtxqueues 1 numrxqueues 1 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
    5131764641 1943009      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
    5351023044 1645093      0       0       0       0 
31: lxce603f37ea079@if30: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 72:83:12:80:de:95 brd ff:ff:ff:ff:ff:ff link-netnsid 3 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
     157119570  881769      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     118090803  952329      0       0       0       0 
39: lxc45f7788338a8@if38: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 8e:b8:1c:fe:bd:8f brd ff:ff:ff:ff:ff:ff link-netnsid 0 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      25450127  328696      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     779488602  478306      0       0       0       0 
43: lxc434d9886f6d8@if42: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ee:5f:57:b2:4f:49 brd ff:ff:ff:ff:ff:ff link-netnsid 5 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:   bytes packets errors dropped  missed   mcast           
    28621829917 4158420      0       0       0       0 
    TX:   bytes packets errors dropped carrier collsns           
     5737756923 3997373      0       0       0       0 
45: lxcc339546cf8ed@if44: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 06:a1:3a:89:56:dc brd ff:ff:ff:ff:ff:ff link-netnsid 6 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:   bytes packets errors dropped  missed   mcast           
     5337311353 5804876      0       0       0       0 
    TX:   bytes packets errors dropped carrier collsns           
    33371326945 6446419      0       0       0       0 
53: lxcd64119894239@if52: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 4a:9c:85:c3:1e:21 brd ff:ff:ff:ff:ff:ff link-netnsid 8 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
     234400579 1125823      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     179303411 1284405      0       0       0       0 
63: lxc3977a6270e7a@if62: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether d6:71:b2:fc:5a:c4 brd ff:ff:ff:ff:ff:ff link-netnsid 9 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      78053292  888395      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      92213938 1042979      0       0       0       0 
65: lxc6382deee4ab8@if64: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether d6:41:84:83:a2:21 brd ff:ff:ff:ff:ff:ff link-netnsid 10 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      82466250  934061      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     263997370  975234      0       0       0       0 
89: lxc22ea99fdaed2@if88: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 8a:2b:44:bb:c7:69 brd ff:ff:ff:ff:ff:ff link-netnsid 12 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
     128598939 1201419      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     395163452 1204208      0       0       0       0 
91: lxc94dec6699d0f@if90: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether ee:52:35:63:c2:fe brd ff:ff:ff:ff:ff:ff link-netnsid 13 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
          5804      81      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          5956      81      0       0       0       0 
93: lxcd8716ad68b0f@if92: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 4e:25:d3:9c:24:f2 brd ff:ff:ff:ff:ff:ff link-netnsid 2 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      19978048  268671      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      29056152  421336      0       0       0       0 
95: lxc209553264675@if94: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether b2:c2:ae:0c:ee:0c brd ff:ff:ff:ff:ff:ff link-netnsid 11 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
          5626      79      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
          5626      79      0       0       0       0 
101: lxc5cddd0950c5b@if100: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 9e:36:2a:53:0f:58 brd ff:ff:ff:ff:ff:ff link-netnsid 14 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      58349071  270854      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     100927863  260298      0       0       0       0 
103: lxc238d768b97ae@if102: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether 4a:27:3b:9a:56:ae brd ff:ff:ff:ff:ff:ff link-netnsid 15 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      59071407  288378      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     102294482  271360      0       0       0       0 
105: lxc8d1805c87601@if104: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether b2:94:e0:9c:d2:d6 brd ff:ff:ff:ff:ff:ff link-netnsid 16 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       6679367   82687      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      29117209   59915      0       0       0       0 
107: lxc09c47b13f40c@if106: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether a2:8a:39:db:ee:6d brd ff:ff:ff:ff:ff:ff link-netnsid 17 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      57112061  262029      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      98376295  254931      0       0       0       0 
109: lxcd440d5ca922b@if108: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether e6:14:5b:dc:4e:03 brd ff:ff:ff:ff:ff:ff link-netnsid 18 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      58567119  265821      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
     100639189  265200      0       0       0       0 
111: lxcdbe084283d2d@if110: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether d2:6f:54:63:72:3b brd ff:ff:ff:ff:ff:ff link-netnsid 19 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
      21361020  220223      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      22583359  258010      0       0       0       0 
115: lxce9a1524bda2c@if114: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP mode DEFAULT group default qlen 1000
    link/ether d6:3a:5a:96:fe:ce brd ff:ff:ff:ff:ff:ff link-netnsid 4 promiscuity 0 minmtu 68 maxmtu 65535 
    veth addrgenmode eui64 numtxqueues 4 numrxqueues 4 gso_max_size 65536 gso_max_segs 65535 
    RX:  bytes packets errors dropped  missed   mcast           
       5905076   54035      0       0       0       0 
    TX:  bytes packets errors dropped carrier collsns           
      26805505   59779      0       0       0       0 
