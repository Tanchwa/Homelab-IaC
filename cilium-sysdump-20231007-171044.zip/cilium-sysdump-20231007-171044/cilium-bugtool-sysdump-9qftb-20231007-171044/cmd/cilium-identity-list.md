Error: Cannot get identities for given labels []. err: Get "http://localhost/v1/identity": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory

> Error while running 'cilium identity list':  exit status 1

