1: hash  flags 0x0
	key 9B  value 1B  max_entries 500  memlock 8192B
2: hash  flags 0x0
	key 9B  value 1B  max_entries 500  memlock 8192B
54: hash  name cilium_auth_map  flags 0x1
	key 12B  value 8B  max_entries 524288  memlock 12582912B
55: array  name cilium_runtime_  flags 0x0
	key 4B  value 8B  max_entries 256  memlock 4096B
56: perf_event_array  name cilium_signals  flags 0x0
	key 4B  value 4B  max_entries 4  memlock 4096B
57: hash  name cilium_node_map  flags 0x1
	key 20B  value 2B  max_entries 16384  memlock 393216B
58: perf_event_array  name cilium_events  flags 0x0
	key 4B  value 4B  max_entries 4  memlock 4096B
59: hash  name cilium_lxc  flags 0x1
	key 20B  value 48B  max_entries 65535  memlock 4718592B
61: percpu_hash  name cilium_metrics  flags 0x1
	key 8B  value 16B  max_entries 1024  memlock 73728B
63: hash  name cilium_lb4_serv  flags 0x1
	key 12B  value 12B  max_entries 65536  memlock 1572864B
64: hash  name cilium_lb4_back  flags 0x1
	key 4B  value 12B  max_entries 65536  memlock 1048576B
65: hash  name cilium_lb4_reve  flags 0x1
	key 2B  value 6B  max_entries 65536  memlock 524288B
66: prog_array  name cilium_call_pol  flags 0x0
	key 4B  value 4B  max_entries 65535  memlock 524288B
	owner_prog_type sched_cls  owner jited
67: lru_hash  name cilium_ct4_glob  flags 0x0
	key 14B  value 56B  max_entries 131072  memlock 9437184B
68: lru_hash  name cilium_ct_any4_  flags 0x0
	key 14B  value 56B  max_entries 65536  memlock 4718592B
69: lru_hash  name cilium_ipv4_fra  flags 0x0
	key 12B  value 4B  max_entries 8192  memlock 131072B
72: array  name cilium_encrypt_  flags 0x0
	key 4B  value 1B  max_entries 1  memlock 4096B
	btf_id 168
73: hash  name cilium_l2_respo  flags 0x1
	key 8B  value 8B  max_entries 4096  memlock 65536B
	btf_id 169
74: prog_array  name cilium_calls_ov  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
75: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
76: prog_array  name cilium_calls_ho  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
79: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
175: lru_hash  name cilium_lb4_reve  flags 0x0
	key 16B  value 8B  max_entries 65536  memlock 1572864B
177: lru_hash  name cilium_nodeport  flags 0x0
	key 4B  value 8B  max_entries 131072  memlock 2097152B
192: prog_array  name cilium_calls_ne  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
529: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
530: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
579: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 20480000B
580: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 2621440B
587: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 1216
818: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
820: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
825: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 1898
827: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
828: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 1909
829: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
831: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
832: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
833: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 1920
870: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
871: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
872: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 1965
898: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
899: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 2020
900: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
902: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
903: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
904: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 2031
1060: lru_hash  name cilium_snat_v4_  flags 0x0
	key 14B  value 40B  max_entries 131072  memlock 7340032B
1061: hash  name cilium_lb_affin  flags 0x1
	key 8B  value 1B  max_entries 65536  memlock 1048576B
1062: lru_hash  name cilium_lb4_affi  flags 0x0
	key 16B  value 16B  max_entries 65536  memlock 2097152B
1063: lpm_trie  name cilium_lb4_sour  flags 0x1
	key 12B  value 1B  max_entries 65536  memlock 1048576B
2546: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2549: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2550: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2551: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2559: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2560: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2561: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2563: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2578: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2580: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2582: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2584: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2585: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2586: prog_array  name cilium_calls_01  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2590: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2591: prog_array  name cilium_calls_03  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2593: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2594: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
2596: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
2597: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
3172: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
3174: prog_array  name cilium_calls_02  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
4588: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 20480000B
4589: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 2621440B
4591: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3659
4592: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3661
4594: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3663
4595: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3692
4596: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3708
4597: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3712
4599: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3726
4600: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3753
4601: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3755
4603: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3771
4604: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3799
4606: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3805
4607: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3831
4609: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3856
4610: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3865
4611: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3874
4612: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3885
4613: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3895
4614: lpm_trie  name cilium_policy_0  flags 0x1
	key 12B  value 24B  max_entries 16384  memlock 655360B
4615: percpu_array  name cilium_tail_cal  flags 0x0
	key 4B  value 44B  max_entries 1  memlock 4096B
	btf_id 3907
4616: prog_array  name cilium_calls_00  flags 0x0
	key 4B  value 4B  max_entries 47  memlock 4096B
	owner_prog_type sched_cls  owner jited
5136: lpm_trie  name cilium_ipcache  flags 0x1
	key 24B  value 12B  max_entries 512000  memlock 20480000B
5137: hash  name cilium_tunnel_m  flags 0x1
	key 20B  value 20B  max_entries 65536  memlock 2621440B
