2023/10/07 17:11:31 missing PID or address
> Error while running 'gops stats $(pidof cilium-agent)':  exit status 1

