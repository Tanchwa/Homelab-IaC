Error: Cannot get status: Get "http://localhost/v1beta/status": dial unix /var/run/cilium/health.sock: connect: connection refused

> Error while running 'cilium-health status --verbose':  exit status 1

