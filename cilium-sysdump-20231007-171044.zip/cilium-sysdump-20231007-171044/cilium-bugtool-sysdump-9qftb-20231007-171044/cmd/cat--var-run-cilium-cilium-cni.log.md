level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Unable to create endpoint" containerID=a113e378a78c82a7e251d3c1518b51f406285dff506fb599cdb14f0f68d7c12e error="Put \"http://localhost/v1/endpoint/cilium-local:0\": EOF" eventUUID=7896ef86-142f-46ff-b396-2d50b57cb9d0 subsys=cilium-cni
level=warning msg="Unable to release IP" error="Delete \"http://localhost/v1/ipam/10.0.0.250?pool=default\": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory\nIs the agent running?" ipAddr=10.0.0.250 pool=default subsys=cilium-cni
level=warning msg="Failed to connect to agent socket at unix:///var/run/cilium/cilium.sock." containerID=a113e378a78c82a7e251d3c1518b51f406285dff506fb599cdb14f0f68d7c12e error="failed to create cilium agent client after 10.000000 seconds timeout: Get \"http://localhost/v1/config\": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory" eventUUID=279919ff-aab3-4a83-9538-27ead7a6a973 subsys=cilium-cni
level=info msg="Agent is down, falling back to deletion queue directory" containerID=a113e378a78c82a7e251d3c1518b51f406285dff506fb599cdb14f0f68d7c12e eventUUID=279919ff-aab3-4a83-9538-27ead7a6a973 subsys=cilium-cni
level=info msg="Queueing deletion request for endpoint" containerID=a113e378a78c82a7e251d3c1518b51f406285dff506fb599cdb14f0f68d7c12e endpointID="container-id:a113e378a78c82a7e251d3c1518b51f406285dff506fb599cdb14f0f68d7c12e" eventUUID=279919ff-aab3-4a83-9538-27ead7a6a973 subsys=cilium-cni
level=info msg="wrote queued deletion file" containerID=a113e378a78c82a7e251d3c1518b51f406285dff506fb599cdb14f0f68d7c12e eventUUID=279919ff-aab3-4a83-9538-27ead7a6a973 subsys=cilium-cni
level=warning msg="Failed to connect to agent socket at unix:///var/run/cilium/cilium.sock." containerID=88bf20763d6648d7d32690c5676a758634df88ec6b49e92f05ae6910a325afd4 error="failed to create cilium agent client after 10.000000 seconds timeout: Get \"http://localhost/v1/config\": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory" eventUUID=f692a2f4-26d4-4e6c-b237-91b7ee251052 subsys=cilium-cni
level=info msg="Agent is down, falling back to deletion queue directory" containerID=88bf20763d6648d7d32690c5676a758634df88ec6b49e92f05ae6910a325afd4 eventUUID=f692a2f4-26d4-4e6c-b237-91b7ee251052 subsys=cilium-cni
level=info msg="Queueing deletion request for endpoint" containerID=88bf20763d6648d7d32690c5676a758634df88ec6b49e92f05ae6910a325afd4 endpointID="container-id:88bf20763d6648d7d32690c5676a758634df88ec6b49e92f05ae6910a325afd4" eventUUID=f692a2f4-26d4-4e6c-b237-91b7ee251052 subsys=cilium-cni
level=info msg="wrote queued deletion file" containerID=88bf20763d6648d7d32690c5676a758634df88ec6b49e92f05ae6910a325afd4 eventUUID=f692a2f4-26d4-4e6c-b237-91b7ee251052 subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Failed to connect to agent socket at unix:///var/run/cilium/cilium.sock." containerID=7d298eb5839e3ad7428c40dea6a9526327ab1ce511451a98dcd369002c19ebd6 error="failed to create cilium agent client after 10.000000 seconds timeout: Get \"http://localhost/v1/config\": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory" eventUUID=9de359f1-eb40-4bb7-9a4e-791eb73d4fec subsys=cilium-cni
level=info msg="Agent is down, falling back to deletion queue directory" containerID=7d298eb5839e3ad7428c40dea6a9526327ab1ce511451a98dcd369002c19ebd6 eventUUID=9de359f1-eb40-4bb7-9a4e-791eb73d4fec subsys=cilium-cni
level=info msg="Queueing deletion request for endpoint" containerID=7d298eb5839e3ad7428c40dea6a9526327ab1ce511451a98dcd369002c19ebd6 endpointID="container-id:7d298eb5839e3ad7428c40dea6a9526327ab1ce511451a98dcd369002c19ebd6" eventUUID=9de359f1-eb40-4bb7-9a4e-791eb73d4fec subsys=cilium-cni
level=info msg="wrote queued deletion file" containerID=7d298eb5839e3ad7428c40dea6a9526327ab1ce511451a98dcd369002c19ebd6 eventUUID=9de359f1-eb40-4bb7-9a4e-791eb73d4fec subsys=cilium-cni
level=warning msg="Failed to connect to agent socket at unix:///var/run/cilium/cilium.sock." containerID=9c0c4331097b3b5683bdf5a17bb56c9d88a14eae2467ef28e4377ddeaea6e501 error="failed to create cilium agent client after 10.000000 seconds timeout: Get \"http://localhost/v1/config\": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory" eventUUID=25870d40-2068-41fa-b23b-02b008b2ab98 subsys=cilium-cni
level=info msg="Agent is down, falling back to deletion queue directory" containerID=9c0c4331097b3b5683bdf5a17bb56c9d88a14eae2467ef28e4377ddeaea6e501 eventUUID=25870d40-2068-41fa-b23b-02b008b2ab98 subsys=cilium-cni
level=info msg="Queueing deletion request for endpoint" containerID=9c0c4331097b3b5683bdf5a17bb56c9d88a14eae2467ef28e4377ddeaea6e501 endpointID="container-id:9c0c4331097b3b5683bdf5a17bb56c9d88a14eae2467ef28e4377ddeaea6e501" eventUUID=25870d40-2068-41fa-b23b-02b008b2ab98 subsys=cilium-cni
level=info msg="wrote queued deletion file" containerID=9c0c4331097b3b5683bdf5a17bb56c9d88a14eae2467ef28e4377ddeaea6e501 eventUUID=25870d40-2068-41fa-b23b-02b008b2ab98 subsys=cilium-cni
level=warning msg="Failed to connect to agent socket at unix:///var/run/cilium/cilium.sock." containerID=480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744 error="failed to create cilium agent client after 10.000000 seconds timeout: Get \"http://localhost/v1/config\": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory" eventUUID=c1fc83eb-51bd-4f1f-ac1c-6ee545e64b31 subsys=cilium-cni
level=info msg="Agent is down, falling back to deletion queue directory" containerID=480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744 eventUUID=c1fc83eb-51bd-4f1f-ac1c-6ee545e64b31 subsys=cilium-cni
level=info msg="Queueing deletion request for endpoint" containerID=480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744 endpointID="container-id:480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744" eventUUID=c1fc83eb-51bd-4f1f-ac1c-6ee545e64b31 subsys=cilium-cni
level=info msg="wrote queued deletion file" containerID=480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744 eventUUID=c1fc83eb-51bd-4f1f-ac1c-6ee545e64b31 subsys=cilium-cni
level=warning msg="Failed to connect to agent socket at unix:///var/run/cilium/cilium.sock." containerID=480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744 error="failed to create cilium agent client after 10.000000 seconds timeout: Get \"http://localhost/v1/config\": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory" eventUUID=18da8d9a-63c0-49be-b825-816ed82d7144 subsys=cilium-cni
level=info msg="Agent is down, falling back to deletion queue directory" containerID=480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744 eventUUID=18da8d9a-63c0-49be-b825-816ed82d7144 subsys=cilium-cni
level=info msg="Queueing deletion request for endpoint" containerID=480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744 endpointID="container-id:480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744" eventUUID=18da8d9a-63c0-49be-b825-816ed82d7144 subsys=cilium-cni
level=info msg="wrote queued deletion file" containerID=480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744 eventUUID=18da8d9a-63c0-49be-b825-816ed82d7144 subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Failed to connect to agent socket at unix:///var/run/cilium/cilium.sock." containerID=480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744 error="failed to create cilium agent client after 10.000000 seconds timeout: Get \"http://localhost/v1/config\": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory" eventUUID=96a1fc7f-c844-4957-acb7-a23ac46a3f43 subsys=cilium-cni
level=info msg="Agent is down, falling back to deletion queue directory" containerID=480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744 eventUUID=96a1fc7f-c844-4957-acb7-a23ac46a3f43 subsys=cilium-cni
level=info msg="Queueing deletion request for endpoint" containerID=480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744 endpointID="container-id:480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744" eventUUID=96a1fc7f-c844-4957-acb7-a23ac46a3f43 subsys=cilium-cni
level=info msg="wrote queued deletion file" containerID=480263511f63e6934a38adb24533d02c2521c7c70c1e34a3d6e84bd768016744 eventUUID=96a1fc7f-c844-4957-acb7-a23ac46a3f43 subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
level=warning msg="Errors encountered while deleting endpoint" error="[DELETE /endpoint/{id}][404] deleteEndpointIdNotFound " subsys=cilium-cni
level=warning msg="Unable to enter namespace \"\", will not delete interface" error="failed to Statfs \"\": no such file or directory" subsys=cilium-cni
