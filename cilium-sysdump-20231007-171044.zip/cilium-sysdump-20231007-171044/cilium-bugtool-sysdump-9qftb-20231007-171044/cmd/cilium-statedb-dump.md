Error: Get "http://localhost/v1/statedb/dump": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
> Error while running 'cilium statedb dump':  exit status 1

