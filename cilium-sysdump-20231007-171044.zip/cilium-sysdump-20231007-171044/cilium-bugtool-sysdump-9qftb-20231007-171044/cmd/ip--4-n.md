192.168.1.10 dev enp0s31f6 lladdr c2:a5:11:ab:b5:26 STALE
192.168.1.4 dev enp0s31f6 lladdr 78:2b:cb:8c:aa:dc REACHABLE
192.168.1.3 dev enp0s31f6 lladdr c2:a5:11:ab:b5:26 STALE
192.168.1.1 dev enp0s31f6 lladdr 40:5d:82:d6:05:18 STALE
192.168.1.15 dev enp0s31f6 lladdr dc:41:a9:1f:5b:53 REACHABLE
