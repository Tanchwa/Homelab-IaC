 17:11:31 up 8 days, 18:43,  0 users,  load average: 2.11, 1.26, 1.19
