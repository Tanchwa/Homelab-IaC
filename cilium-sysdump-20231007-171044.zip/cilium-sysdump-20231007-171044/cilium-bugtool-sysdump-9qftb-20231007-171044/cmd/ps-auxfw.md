USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
root          17  0.0  0.1 723232 13100 ?        Ssl  17:11   0:00 cilium-bugtool --archiveType=gz
root          32  0.0  0.0   7060  1560 ?        R    17:11   0:00  \_ ps auxfw
root          33  0.0  0.0   4528  1376 ?        R    17:11   0:00  \_ ip a
root          35  0.0  0.0   4396  1380 ?        R    17:11   0:00  \_ ip -4 r
root          37  0.0  0.0   4360  1456 ?        R    17:11   0:00  \_ bash -c ip -6 r
root           1  0.0  0.0   2788   996 ?        Ss   17:11   0:00 /bin/sleep 1d
