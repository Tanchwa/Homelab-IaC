top - 17:11:31 up 8 days, 18:43,  0 users,  load average: 2.11, 1.26, 1.19
Tasks:   6 total,   4 running,   2 sleeping,   0 stopped,   0 zombie
%Cpu(s): 27.1 us, 40.7 sy,  0.0 ni, 28.8 id,  3.4 wa,  0.0 hi,  0.0 si,  0.0 st
MiB Mem :   7819.3 total,    318.1 free,   2689.2 used,   4811.9 buff/cache
MiB Swap:      0.0 total,      0.0 free,      0.0 used.   4787.2 avail Mem 

    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND
    110 root      20   0    3540   1216   1096 R  26.7   0.0   0:00.04 bpftool
    125 root      20   0    3540   1252   1132 R  13.3   0.0   0:00.02 bpftool
     17 root      20   0  723808  13884   9792 S   6.7   0.2   0:00.03 cilium-+
      1 root      20   0    2788    996    904 S   0.0   0.0   0:00.00 sleep
     49 root      20   0    7180   2972   2644 R   0.0   0.0   0:00.00 top
    135 root      20   0    3540   1248   1124 R   0.0   0.0   0:00.00 bpftool
