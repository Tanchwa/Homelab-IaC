Error: could not get map name events: Get "http://localhost/v1/map/cilium_lb4_backends_v3/events?follow=false": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
> Error while running 'cilium map events cilium_lb4_backends_v3 -o json':  exit status 1

