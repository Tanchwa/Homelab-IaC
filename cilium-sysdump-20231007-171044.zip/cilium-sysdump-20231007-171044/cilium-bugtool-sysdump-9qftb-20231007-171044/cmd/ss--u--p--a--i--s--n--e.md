Total: 777
TCP:   541 (estab 358, closed 166, orphaned 0, timewait 80)

Transport Total     IP        IPv6
RAW	  1         0         1        
UDP	  4         3         1        
TCP	  375       297       78       
INET	  380       300       80       
FRAG	  0         0         0        

Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
Failed to open cgroup2 by ID
State  Recv-Q Send-Q          Local Address:Port Peer Address:PortProcess                                                    
UNCONN 0      0               127.0.0.53%lo:53        0.0.0.0:*    uid:102 ino:33342 sk:22bdf cgroup:unreachable:14d6 <->    
UNCONN 0      0      192.168.1.31%enp0s31f6:68        0.0.0.0:*    uid:101 ino:16123624 sk:4f0db9 cgroup:unreachable:1474 <->
UNCONN 0      0                     0.0.0.0:8472      0.0.0.0:*    ino:100393 sk:4f0dba cgroup:unreachable:2c4b <->          
UNCONN 0      0                        [::]:8472         [::]:*    ino:100392 sk:4f0dbb cgroup:unreachable:2c4b v6only:1 <-> 
