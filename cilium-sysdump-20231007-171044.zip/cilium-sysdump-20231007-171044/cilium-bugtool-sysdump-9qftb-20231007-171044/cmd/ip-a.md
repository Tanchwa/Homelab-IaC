1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
2: enp0s31f6: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc fq_codel state UP group default qlen 1000
    link/ether f4:8e:38:82:a9:dc brd ff:ff:ff:ff:ff:ff
    inet 192.168.1.31/24 metric 100 brd 192.168.1.255 scope global dynamic enp0s31f6
       valid_lft 63480sec preferred_lft 63480sec
    inet6 fe80::f68e:38ff:fe82:a9dc/64 scope link 
       valid_lft forever preferred_lft forever
3: cilium_net@cilium_host: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 6a:1b:03:db:72:c8 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::681b:3ff:fedb:72c8/64 scope link 
       valid_lft forever preferred_lft forever
4: cilium_host@cilium_net: <BROADCAST,MULTICAST,NOARP,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 1e:82:1b:84:22:ae brd ff:ff:ff:ff:ff:ff
    inet 10.0.0.91/32 scope global cilium_host
       valid_lft forever preferred_lft forever
    inet6 fe80::1c82:1bff:fe84:22ae/64 scope link 
       valid_lft forever preferred_lft forever
5: cilium_vxlan: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UNKNOWN group default qlen 1000
    link/ether 0a:7c:84:bb:ae:85 brd ff:ff:ff:ff:ff:ff
    inet6 fe80::87c:84ff:febb:ae85/64 scope link 
       valid_lft forever preferred_lft forever
31: lxce603f37ea079@if30: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 72:83:12:80:de:95 brd ff:ff:ff:ff:ff:ff link-netnsid 3
    inet6 fe80::7083:12ff:fe80:de95/64 scope link 
       valid_lft forever preferred_lft forever
39: lxc45f7788338a8@if38: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 8e:b8:1c:fe:bd:8f brd ff:ff:ff:ff:ff:ff link-netnsid 0
    inet6 fe80::8cb8:1cff:fefe:bd8f/64 scope link 
       valid_lft forever preferred_lft forever
43: lxc434d9886f6d8@if42: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ee:5f:57:b2:4f:49 brd ff:ff:ff:ff:ff:ff link-netnsid 5
    inet6 fe80::ec5f:57ff:feb2:4f49/64 scope link 
       valid_lft forever preferred_lft forever
45: lxcc339546cf8ed@if44: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 06:a1:3a:89:56:dc brd ff:ff:ff:ff:ff:ff link-netnsid 6
    inet6 fe80::4a1:3aff:fe89:56dc/64 scope link 
       valid_lft forever preferred_lft forever
53: lxcd64119894239@if52: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:9c:85:c3:1e:21 brd ff:ff:ff:ff:ff:ff link-netnsid 8
    inet6 fe80::489c:85ff:fec3:1e21/64 scope link 
       valid_lft forever preferred_lft forever
63: lxc3977a6270e7a@if62: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether d6:71:b2:fc:5a:c4 brd ff:ff:ff:ff:ff:ff link-netnsid 9
    inet6 fe80::d471:b2ff:fefc:5ac4/64 scope link 
       valid_lft forever preferred_lft forever
65: lxc6382deee4ab8@if64: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether d6:41:84:83:a2:21 brd ff:ff:ff:ff:ff:ff link-netnsid 10
    inet6 fe80::d441:84ff:fe83:a221/64 scope link 
       valid_lft forever preferred_lft forever
89: lxc22ea99fdaed2@if88: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 8a:2b:44:bb:c7:69 brd ff:ff:ff:ff:ff:ff link-netnsid 12
    inet6 fe80::882b:44ff:febb:c769/64 scope link 
       valid_lft forever preferred_lft forever
91: lxc94dec6699d0f@if90: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether ee:52:35:63:c2:fe brd ff:ff:ff:ff:ff:ff link-netnsid 13
    inet6 fe80::ec52:35ff:fe63:c2fe/64 scope link 
       valid_lft forever preferred_lft forever
93: lxcd8716ad68b0f@if92: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 4e:25:d3:9c:24:f2 brd ff:ff:ff:ff:ff:ff link-netnsid 2
    inet6 fe80::4c25:d3ff:fe9c:24f2/64 scope link 
       valid_lft forever preferred_lft forever
95: lxc209553264675@if94: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether b2:c2:ae:0c:ee:0c brd ff:ff:ff:ff:ff:ff link-netnsid 11
    inet6 fe80::b0c2:aeff:fe0c:ee0c/64 scope link 
       valid_lft forever preferred_lft forever
101: lxc5cddd0950c5b@if100: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 9e:36:2a:53:0f:58 brd ff:ff:ff:ff:ff:ff link-netnsid 14
    inet6 fe80::9c36:2aff:fe53:f58/64 scope link 
       valid_lft forever preferred_lft forever
103: lxc238d768b97ae@if102: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether 4a:27:3b:9a:56:ae brd ff:ff:ff:ff:ff:ff link-netnsid 15
    inet6 fe80::4827:3bff:fe9a:56ae/64 scope link 
       valid_lft forever preferred_lft forever
105: lxc8d1805c87601@if104: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether b2:94:e0:9c:d2:d6 brd ff:ff:ff:ff:ff:ff link-netnsid 16
    inet6 fe80::b094:e0ff:fe9c:d2d6/64 scope link 
       valid_lft forever preferred_lft forever
107: lxc09c47b13f40c@if106: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether a2:8a:39:db:ee:6d brd ff:ff:ff:ff:ff:ff link-netnsid 17
    inet6 fe80::a08a:39ff:fedb:ee6d/64 scope link 
       valid_lft forever preferred_lft forever
109: lxcd440d5ca922b@if108: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether e6:14:5b:dc:4e:03 brd ff:ff:ff:ff:ff:ff link-netnsid 18
    inet6 fe80::e414:5bff:fedc:4e03/64 scope link 
       valid_lft forever preferred_lft forever
111: lxcdbe084283d2d@if110: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether d2:6f:54:63:72:3b brd ff:ff:ff:ff:ff:ff link-netnsid 19
    inet6 fe80::d06f:54ff:fe63:723b/64 scope link 
       valid_lft forever preferred_lft forever
115: lxce9a1524bda2c@if114: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc noqueue state UP group default qlen 1000
    link/ether d6:3a:5a:96:fe:ce brd ff:ff:ff:ff:ff:ff link-netnsid 4
    inet6 fe80::d43a:5aff:fe96:fece/64 scope link 
       valid_lft forever preferred_lft forever
