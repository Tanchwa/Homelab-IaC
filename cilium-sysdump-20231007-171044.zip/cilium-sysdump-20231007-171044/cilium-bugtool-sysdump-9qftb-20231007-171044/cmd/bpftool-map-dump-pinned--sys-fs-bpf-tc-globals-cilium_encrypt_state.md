[{
        "key": 0,
        "value": {
            "encrypt_key": 0
        }
    }
]
