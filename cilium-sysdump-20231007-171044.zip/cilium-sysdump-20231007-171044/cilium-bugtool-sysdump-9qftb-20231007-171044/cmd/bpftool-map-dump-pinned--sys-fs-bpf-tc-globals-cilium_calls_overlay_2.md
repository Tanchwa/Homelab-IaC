key: 01 00 00 00  value: 3c 67 00 00
key: 07 00 00 00  value: 3b 67 00 00
key: 0f 00 00 00  value: 35 67 00 00
key: 11 00 00 00  value: 39 67 00 00
key: 24 00 00 00  value: 38 67 00 00
key: 26 00 00 00  value: 3a 67 00 00
Found 6 elements
