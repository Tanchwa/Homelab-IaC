Get "http://localhost/v1/cgroup-dump-metadata": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?
> Error while running 'cilium cgroups list -o json':  exit status 1

