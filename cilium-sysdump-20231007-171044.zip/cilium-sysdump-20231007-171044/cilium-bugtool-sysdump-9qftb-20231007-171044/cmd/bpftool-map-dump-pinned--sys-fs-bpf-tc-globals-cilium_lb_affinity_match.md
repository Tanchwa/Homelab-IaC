key: 57 00 00 00 00 48 00 00  value: 00
key: 58 00 00 00 00 4b 00 00  value: 00
key: 5c 00 00 00 00 49 00 00  value: 00
key: 59 00 00 00 00 47 00 00  value: 00
key: 5e 00 00 00 00 4b 00 00  value: 00
key: 5d 00 00 00 00 47 00 00  value: 00
key: 5a 00 00 00 00 49 00 00  value: 00
key: 5b 00 00 00 00 48 00 00  value: 00
Found 8 elements
