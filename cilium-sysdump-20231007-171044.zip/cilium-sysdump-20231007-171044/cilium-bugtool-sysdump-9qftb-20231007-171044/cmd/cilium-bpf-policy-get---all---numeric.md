Endpoint ID: 66
Path: /sys/fs/bpf/tc/globals/cilium_policy_00066

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    206     2         0        


Endpoint ID: 68
Path: /sys/fs/bpf/tc/globals/cilium_policy_00068

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0          0         0        
Allow    Ingress     1          ANY          NONE         disabled    22529286   257907    0        
Allow    Egress      0          ANY          NONE         disabled    2326       28        0        


Endpoint ID: 139
Path: /sys/fs/bpf/tc/globals/cilium_policy_00139

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES       PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    39606394    452855    0        
Allow    Ingress     1094       8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     2955       8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     3360       8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     3647       8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     3714       8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     4226       8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     4327       8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     5202       8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     6608       8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     8745       8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     8786       8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     9538       8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     11923      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     14195      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     18542      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     22426      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     24759      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     34237      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     34495      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     35547      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     35547      8081/TCP     NONE         disabled    346860489   2471107   24       
Allow    Ingress     35673      8081/TCP     NONE         disabled    295409      3367      24       
Allow    Ingress     35673      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     40771      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     44101      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     48390      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     50982      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     50982      8081/TCP     NONE         disabled    0           0         24       
Allow    Ingress     51610      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     56903      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     56903      8081/TCP     NONE         disabled    151079      2281      24       
Allow    Ingress     58805      8084/TCP     NONE         disabled    0           0         24       
Allow    Ingress     59194      8084/TCP     NONE         disabled    0           0         24       
Allow    Egress      0          ANY          NONE         disabled    563205973   836738    0        


Endpoint ID: 292
Path: /sys/fs/bpf/tc/globals/cilium_policy_00292

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0          0         0        
Allow    Ingress     1          ANY          NONE         disabled    0          0         0        
Allow    Egress      0          ANY          NONE         disabled    58343403   270774    0        


Endpoint ID: 323
Path: /sys/fs/bpf/tc/globals/cilium_policy_00323

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    95040248   332047    0        
Allow    Ingress     1          ANY          NONE         disabled    84250425   952177    0        
Allow    Egress      0          ANY          NONE         disabled    0          0         0        


Endpoint ID: 508
Path: /sys/fs/bpf/tc/globals/cilium_policy_00508

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES        PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    29767666     344281    0        
Allow    Ingress     1094       8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     2955       8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     3360       8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     3647       8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     3714       8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     4226       8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     4327       8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     5202       8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     6608       8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     8745       8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     8786       8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     9538       8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     11923      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     14195      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     18542      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     22426      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     24759      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     34237      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     34495      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     35547      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     35673      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     40771      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     44101      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     48390      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     50982      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     51610      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     56903      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     58805      8082/TCP     NONE         disabled    0            0         24       
Allow    Ingress     59194      8082/TCP     NONE         disabled    0            0         24       
Allow    Egress      0          ANY          NONE         disabled    5309662774   5520186   0        


Endpoint ID: 595
Path: /sys/fs/bpf/tc/globals/cilium_policy_00595

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 684
Path: /sys/fs/bpf/tc/globals/cilium_policy_00684

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0          0         0        
Allow    Ingress     1          ANY          NONE         disabled    87630656   1012774   0        
Allow    Egress      0          ANY          NONE         disabled    4095008    46378     0        


Endpoint ID: 699
Path: /sys/fs/bpf/tc/globals/cilium_policy_00699

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0          0         0        
Allow    Ingress     1          ANY          NONE         disabled    0          0         0        
Allow    Egress      0          ANY          NONE         disabled    58562714   265747    0        


Endpoint ID: 757
Path: /sys/fs/bpf/tc/globals/cilium_policy_00757

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    1870       24        0        
Allow    Ingress     1          ANY          NONE         disabled    31379366   280236    0        
Allow    Egress      0          ANY          NONE         disabled    90088771   1011498   0        


Endpoint ID: 914
Path: /sys/fs/bpf/tc/globals/cilium_policy_00914

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Ingress     1          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 1124
Path: /sys/fs/bpf/tc/globals/cilium_policy_01124

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0          0         0        
Allow    Ingress     1          ANY          NONE         disabled    0          0         0        
Allow    Egress      0          ANY          NONE         disabled    59065809   288299    0        


Endpoint ID: 1221
Path: /sys/fs/bpf/tc/globals/cilium_policy_01221

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    0         0         0        
Allow    Egress      0          ANY          NONE         disabled    6673769   82608     0        


Endpoint ID: 1224
Path: /sys/fs/bpf/tc/globals/cilium_policy_01224

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    39342701   127269    0        
Allow    Ingress     1          ANY          NONE         disabled    66901065   767423    0        
Allow    Egress      0          ANY          NONE         disabled    6967749    84299     0        


Endpoint ID: 1804
Path: /sys/fs/bpf/tc/globals/cilium_policy_01804

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0          0         0        
Allow    Ingress     1          ANY          NONE         disabled    0          0         0        
Allow    Egress      0          ANY          NONE         disabled    82453582   933881    0        


Endpoint ID: 2048
Path: /sys/fs/bpf/tc/globals/cilium_policy_02048

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES   PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0       0         0        
Allow    Egress      0          ANY          NONE         disabled    0       0         0        


Endpoint ID: 2104
Path: /sys/fs/bpf/tc/globals/cilium_policy_02104

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     1          ANY          NONE         disabled    16590096   243972    0        
Allow    Ingress     1094       9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     2955       9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     3360       9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     3647       9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     3714       9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     4226       9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     4327       9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     5202       9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     6608       9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     8745       9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     8786       9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     9538       9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     11923      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     14195      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     18542      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     22426      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     24759      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     34237      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     34495      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     35547      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     35673      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     40771      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     44101      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     48390      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     50982      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     51610      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     56903      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     58805      9001/TCP     NONE         disabled    0          0         24       
Allow    Ingress     59194      9001/TCP     NONE         disabled    0          0         24       
Allow    Egress      0          ANY          NONE         disabled    16893907   206462    0        


Endpoint ID: 2533
Path: /sys/fs/bpf/tc/globals/cilium_policy_02533

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES     PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0         0         0        
Allow    Ingress     1          ANY          NONE         disabled    3942180   44671     0        
Allow    Egress      0          ANY          NONE         disabled    2031792   13894     0        


Endpoint ID: 2647
Path: /sys/fs/bpf/tc/globals/cilium_policy_02647

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    16801034   232905    0        
Allow    Ingress     1          ANY          NONE         disabled    12249516   188352    0        
Allow    Egress      0          ANY          NONE         disabled    0          0         0        


Endpoint ID: 3403
Path: /sys/fs/bpf/tc/globals/cilium_policy_03403

POLICY   DIRECTION   IDENTITY   PORT/PROTO   PROXY PORT   AUTH TYPE   BYTES      PACKETS   PREFIX   
Allow    Ingress     0          ANY          NONE         disabled    0          0         0        
Allow    Ingress     1          ANY          NONE         disabled    0          0         0        
Allow    Egress      0          ANY          NONE         disabled    57106463   261950    0        


