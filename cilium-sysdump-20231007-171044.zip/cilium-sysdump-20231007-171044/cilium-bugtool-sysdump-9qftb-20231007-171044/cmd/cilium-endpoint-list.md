Error: cannot get endpoint list: Get "http://localhost/v1/endpoint": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?

> Error while running 'cilium endpoint list':  exit status 1

