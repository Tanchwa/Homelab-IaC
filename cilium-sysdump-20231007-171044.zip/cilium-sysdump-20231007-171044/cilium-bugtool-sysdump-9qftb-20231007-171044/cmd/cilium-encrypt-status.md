Error: Cannot get daemon encryption status: Get "http://localhost/v1/healthz": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
> Error while running 'cilium encrypt status':  exit status 1

