qdisc noqueue 0: dev lo root refcnt 2 
qdisc fq_codel 0: dev enp0s31f6 root refcnt 2 limit 10240p flows 1024 quantum 1514 target 5ms interval 100ms memory_limit 32Mb ecn drop_batch 64 
qdisc clsact ffff: dev enp0s31f6 parent ffff:fff1 
qdisc noqueue 0: dev cilium_net root refcnt 2 
qdisc clsact ffff: dev cilium_net parent ffff:fff1 
qdisc noqueue 0: dev cilium_host root refcnt 2 
qdisc clsact ffff: dev cilium_host parent ffff:fff1 
qdisc noqueue 0: dev cilium_vxlan root refcnt 2 
qdisc clsact ffff: dev cilium_vxlan parent ffff:fff1 
qdisc noqueue 0: dev lxce603f37ea079 root refcnt 2 
qdisc clsact ffff: dev lxce603f37ea079 parent ffff:fff1 
qdisc noqueue 0: dev lxc45f7788338a8 root refcnt 2 
qdisc clsact ffff: dev lxc45f7788338a8 parent ffff:fff1 
qdisc noqueue 0: dev lxc434d9886f6d8 root refcnt 2 
qdisc clsact ffff: dev lxc434d9886f6d8 parent ffff:fff1 
qdisc noqueue 0: dev lxcc339546cf8ed root refcnt 2 
qdisc clsact ffff: dev lxcc339546cf8ed parent ffff:fff1 
qdisc noqueue 0: dev lxcd64119894239 root refcnt 2 
qdisc clsact ffff: dev lxcd64119894239 parent ffff:fff1 
qdisc noqueue 0: dev lxc3977a6270e7a root refcnt 2 
qdisc clsact ffff: dev lxc3977a6270e7a parent ffff:fff1 
qdisc noqueue 0: dev lxc6382deee4ab8 root refcnt 2 
qdisc clsact ffff: dev lxc6382deee4ab8 parent ffff:fff1 
qdisc noqueue 0: dev lxc22ea99fdaed2 root refcnt 2 
qdisc clsact ffff: dev lxc22ea99fdaed2 parent ffff:fff1 
qdisc noqueue 0: dev lxc94dec6699d0f root refcnt 2 
qdisc clsact ffff: dev lxc94dec6699d0f parent ffff:fff1 
qdisc noqueue 0: dev lxcd8716ad68b0f root refcnt 2 
qdisc clsact ffff: dev lxcd8716ad68b0f parent ffff:fff1 
qdisc noqueue 0: dev lxc209553264675 root refcnt 2 
qdisc clsact ffff: dev lxc209553264675 parent ffff:fff1 
qdisc noqueue 0: dev lxc5cddd0950c5b root refcnt 2 
qdisc clsact ffff: dev lxc5cddd0950c5b parent ffff:fff1 
qdisc noqueue 0: dev lxc238d768b97ae root refcnt 2 
qdisc clsact ffff: dev lxc238d768b97ae parent ffff:fff1 
qdisc noqueue 0: dev lxc8d1805c87601 root refcnt 2 
qdisc clsact ffff: dev lxc8d1805c87601 parent ffff:fff1 
qdisc noqueue 0: dev lxc09c47b13f40c root refcnt 2 
qdisc clsact ffff: dev lxc09c47b13f40c parent ffff:fff1 
qdisc noqueue 0: dev lxcd440d5ca922b root refcnt 2 
qdisc clsact ffff: dev lxcd440d5ca922b parent ffff:fff1 
qdisc noqueue 0: dev lxcdbe084283d2d root refcnt 2 
qdisc clsact ffff: dev lxcdbe084283d2d parent ffff:fff1 
qdisc noqueue 0: dev lxce9a1524bda2c root refcnt 2 
qdisc clsact ffff: dev lxce9a1524bda2c parent ffff:fff1 
