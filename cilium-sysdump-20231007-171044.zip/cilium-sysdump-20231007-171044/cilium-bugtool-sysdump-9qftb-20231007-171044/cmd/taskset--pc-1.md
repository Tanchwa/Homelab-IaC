pid 1's current affinity list: 0-3
