search .
nameserver 192.168.1.1
