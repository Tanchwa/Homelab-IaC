Error: Get "http://localhost/v1/map": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
> Error while running 'cilium map list --verbose':  exit status 1

