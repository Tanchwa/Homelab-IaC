Error: Cannot get policy: Get "http://localhost/v1/policy": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?

> Error while running 'cilium policy get':  exit status 1

