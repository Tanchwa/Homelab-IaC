2023/10/07 17:11:31 missing PID or address
> Error while running 'gops stack $(pidof cilium-agent)':  exit status 1

