Error: Cannot get metrics list: Get "http://localhost/v1/metrics/": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
> Error while running 'cilium metrics list':  exit status 1

