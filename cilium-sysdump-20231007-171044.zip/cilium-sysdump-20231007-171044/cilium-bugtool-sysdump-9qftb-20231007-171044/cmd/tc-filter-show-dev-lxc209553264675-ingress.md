filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc209553264675 direct-action not_in_hw id 26571 tag 5a6fe57069b94320 jited 
