default via 192.168.1.1 dev enp0s31f6 proto dhcp src 192.168.1.31 metric 100 
10.0.0.0/24 via 10.0.0.91 dev cilium_host proto kernel src 10.0.0.91 
10.0.0.91 dev cilium_host proto kernel scope link 
10.0.1.0/24 via 10.0.0.91 dev cilium_host proto kernel src 10.0.0.91 mtu 1450 
192.168.1.0/24 dev enp0s31f6 proto kernel scope link src 192.168.1.31 metric 100 
192.168.1.1 dev enp0s31f6 proto dhcp scope link src 192.168.1.31 metric 100 
