filter protocol all pref 1 bpf chain 0 
filter protocol all pref 1 bpf chain 0 handle 0x1 cil_from_container-lxc5cddd0950c5b direct-action not_in_hw id 26534 tag 0628de34bb4a83d9 jited 
