CgroupPath
ID       AttachType      AttachFlags     Name           
/run/cilium/cgroupv2
26411    cgroup_inet4_connect multi           cil_sock4_connect
26415    cgroup_inet6_connect multi           cil_sock6_connect
26417    cgroup_inet4_post_bind multi           cil_sock4_post_bind
26412    cgroup_inet6_post_bind multi           cil_sock6_post_bind
26414    cgroup_udp4_sendmsg multi           cil_sock4_sendmsg
26419    cgroup_udp6_sendmsg multi           cil_sock6_sendmsg
26418    cgroup_udp4_recvmsg multi           cil_sock4_recvmsg
26420    cgroup_udp6_recvmsg multi           cil_sock6_recvmsg
26413    cgroup_inet4_getpeername multi           cil_sock4_getpeername
26416    cgroup_inet6_getpeername multi           cil_sock6_getpeername
/run/cilium/cgroupv2/system.slice/systemd-networkd.service
    13352    cgroup_device   multi                          
/run/cilium/cgroupv2/system.slice/systemd-udevd.service
    13341    cgroup_inet_ingress multi                          
    13340    cgroup_inet_egress multi                          
    13339    cgroup_device   multi                          
/run/cilium/cgroupv2/system.slice/systemd-journald.service
    13386    cgroup_inet_ingress multi                          
    13385    cgroup_inet_egress multi                          
    13384    cgroup_device   multi                          
/run/cilium/cgroupv2/system.slice/snap.canonical-livepatch.canonical-livepatchd.service
    95       cgroup_device                                  
/run/cilium/cgroupv2/system.slice/upower.service
    13369    cgroup_inet_ingress multi                          
    13368    cgroup_inet_egress multi                          
/run/cilium/cgroupv2/system.slice/systemd-resolved.service
    13387    cgroup_device   multi                          
/run/cilium/cgroupv2/system.slice/systemd-timesyncd.service
    13344    cgroup_device   multi                          
/run/cilium/cgroupv2/system.slice/systemd-logind.service
    13350    cgroup_inet_ingress multi                          
    13349    cgroup_inet_egress multi                          
    13348    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode8355bf4_0ae4_4eae_9922_f4b782d97b08.slice/cri-containerd-8bbf0ed9b6857e3874efa7b4d7aee3e2582ece226a8b10c578e5b3ac0267344b.scope
    3999     cgroup_device   multi                          
    13382    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode8355bf4_0ae4_4eae_9922_f4b782d97b08.slice/cri-containerd-7f27e1906938e70df9695afcb9f37f39971d5e23e4b8a8d1b65302b187e336fc.scope
    3995     cgroup_device   multi                          
    13336    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pode8355bf4_0ae4_4eae_9922_f4b782d97b08.slice/cri-containerd-31d21ed5d69af77dd3caf63f91eb7a0a22f2686bba9cf2be7cb21aa65ca4e957.scope
    3983     cgroup_device   multi                          
    13390    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podcbbefc5d_e41e_45e0_bbf8_b957901d5dde.slice/cri-containerd-22f834aefb3e5a28f0014cae0eeb7bbf9dde18e4c1cd5fa2ad50004799d219a2.scope
    28174    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3047c5148ed578353a060e745057efa1.slice/cri-containerd-a71b50d906238f3bba4fa9d542745073e0c89fe27f2d6530306d595f757e5e96.scope
    385      cgroup_device   multi                          
    13376    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3047c5148ed578353a060e745057efa1.slice/cri-containerd-131f2b406e89be0b714dc5321ae82f9a649bd1e8ab4ace31bfdddcc5c8d306b7.scope
    397      cgroup_device   multi                          
    13354    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1e578c5_c358_456d_8202_9ed52e82098e.slice/cri-containerd-ea74df79087f98a7496ca9466f52b54037fd893f0a375b624baad01ff670c7f2.scope
    2785     cgroup_device   multi                          
    13361    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podb1e578c5_c358_456d_8202_9ed52e82098e.slice/cri-containerd-31b3ececb15ae8aaf8b8afe462f95e99510514bf452650e018cca3b996f2b30e.scope
    2789     cgroup_device   multi                          
    13373    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod158e3c4f69614fa3d131f10c798a442a.slice/cri-containerd-36df23fec356600b360ca96571acafe9db28a3cfaaa09d348023af0c0fce78c1.scope
    393      cgroup_device   multi                          
    13377    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod158e3c4f69614fa3d131f10c798a442a.slice/cri-containerd-997f170b906496eb8ccd5ea6a6ff2ff0f7f8d7393ff98a260487819253e6a2c6.scope
    377      cgroup_device   multi                          
    13372    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda38498e7_9406_4e89_87b6_02393c71f4c6.slice/cri-containerd-21ae94c08f73a48758d285db5fef6832e08d930f0eb3d53bebd1398c1545147a.scope
    15563    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-poda38498e7_9406_4e89_87b6_02393c71f4c6.slice/cri-containerd-cedaf233cef481e6ea0fcc2fc3b3f9a0941f3d7b0353036031d15433f027e2bb.scope
    15559    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod182b708a_c251_4000_a19a_b530cb2849c7.slice/cri-containerd-80f18fa6abecbc70f6e96c02bff2d28a690e3924dc05dce7e90db1625090cb66.scope
    13074    cgroup_device   multi                          
    13364    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod182b708a_c251_4000_a19a_b530cb2849c7.slice/cri-containerd-e00605cb57b5dedf49d7cdb6013597579b0dcd9ec2978a3e1c487cb1ff042fff.scope
    13199    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9ef4fa887c0a6b799fb81a3cb140549.slice/cri-containerd-ae051e7651681135133ef60c64865bd857c46df072e9d9dded129e48c34e4442.scope
    389      cgroup_device   multi                          
    13389    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-podf9ef4fa887c0a6b799fb81a3cb140549.slice/cri-containerd-b0aa5281d6b74e1913fd3dddee44df3500b40ee49b50bc1506442c372912e78f.scope
    373      cgroup_device   multi                          
    13358    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3994da3564cc205d26f96119e0ab7045.slice/cri-containerd-fa46e4ba06b04546d5370b2721f545763496e8c209efabfc8c8b5d060ee72e5b.scope
    381      cgroup_device   multi                          
    13379    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-burstable.slice/kubepods-burstable-pod3994da3564cc205d26f96119e0ab7045.slice/cri-containerd-27e9f04de6b9e382e9351be76bbada92cb89416da046197b4ff5b36d8aadacd4.scope
    401      cgroup_device   multi                          
    13346    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode401f13d_193f_494a_95cc_07dd3aa84463.slice/cri-containerd-7845873a7bbb810c6d08e71e06b5b75561e284612705658fb17b2c4bd7a5ada1.scope
    13215    cgroup_device   multi                          
    13383    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pode401f13d_193f_494a_95cc_07dd3aa84463.slice/cri-containerd-f6a95f750a7ec7a396f52b581fe9af67107fa47be9f54b592d1ca2684d8be649.scope
    13188    cgroup_device   multi                          
    13394    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6d9f17c0_6669_4a02_8259_edb349070706.slice/cri-containerd-dbb7ded805f74de2f2d4d718121b631c6b52a05f680ccb503fd291f1568efaa2.scope
    13112    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6d9f17c0_6669_4a02_8259_edb349070706.slice/cri-containerd-1cea89e4991229f7545abf501f8a152466af9aca99da117be8ec22a627b9a821.scope
    13070    cgroup_device   multi                          
    13363    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0935672b_b88d_4a19_849f_72927158ecf8.slice/cri-containerd-f537ad7a6a20bfeed062fa80c790eadf86dd11a7dc24d990e40e8c15452120ac.scope
    3838     cgroup_device   multi                          
    13366    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod0935672b_b88d_4a19_849f_72927158ecf8.slice/cri-containerd-59dcda657e699c0cc552de572f9b9ec5a61e294fa570c31c6cd7f2371c74a188.scope
    3792     cgroup_device   multi                          
    13365    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01b6177a_be51_4996_be5e_f753ae25ca67.slice/cri-containerd-97cd111f39e1983331a73b703796b9e6ded9d99eb9e71f907a9f9b2560f81048.scope
    3820     cgroup_device   multi                          
    13362    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod01b6177a_be51_4996_be5e_f753ae25ca67.slice/cri-containerd-33bfd989839babf4cf4b6641e5214389c711f4be5d9076a784d37bff393593b0.scope
    3854     cgroup_device   multi                          
    13392    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a59ab9b_2391_4071_af82_c6b6a636dc58.slice/cri-containerd-f6093a8a4b8c86c52b9b429d63880c06ac7292649b1e2ceda244d3ec95ae2305.scope
    4097     cgroup_device   multi                          
    13338    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2a59ab9b_2391_4071_af82_c6b6a636dc58.slice/cri-containerd-3090353ee9c5b7db3f6619046b4c0509dffcd51bf68fa93b29403122129be722.scope
    4129     cgroup_device   multi                          
    13334    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod810e3353_86e8_4395_b3c9_42e6e8292983.slice/cri-containerd-2ec4f5d47f0d2de23f1a0164de15a2c8fda3bc3452c364296f458ec8f8d22457.scope
    13154    cgroup_device   multi                          
    13331    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod810e3353_86e8_4395_b3c9_42e6e8292983.slice/cri-containerd-484fabde30fb3193f769576400f0ed1146304a96da5959d882d2a0ab4f10f3a6.scope
    13211    cgroup_device   multi                          
    13335    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1506dab7_f9f1_4969_a2de_616c31851225.slice/cri-containerd-21815bb3b173f727e25aaf99f942cba2aebd8fc30bd44a645ac54fef7eacbab7.scope
    13027    cgroup_device   multi                          
    13337    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod1506dab7_f9f1_4969_a2de_616c31851225.slice/cri-containerd-5fa28bc5254c14e1d998a71cbdd05ee569ba36d16a387e918e7de6f57f346121.scope
    13046    cgroup_device   multi                          
    13367    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ed7e7e4_1d9d_4578_ad21_077892c137b6.slice/cri-containerd-0c6d9d153b66e985730784d45cf2bed0851761ad39683906166371b52136501a.scope
    13819    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod4ed7e7e4_1d9d_4578_ad21_077892c137b6.slice/cri-containerd-3ac03a619c0c5f0e7bfd05e15be52379a5a6161c2d2be6911b4dd5a2d3eb98e1.scope
    13815    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6271e68c_e942_45fd_ab6c_9938112bebc5.slice/cri-containerd-275c381728f3fe0806c6c687da03ec85051c4b42aad2840a1f8180d08d306385.scope
    13150    cgroup_device   multi                          
    13359    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod6271e68c_e942_45fd_ab6c_9938112bebc5.slice/cri-containerd-1194834a4f8e122f732144c95ad4c8c34238361f83b64329a4cf2c8d247d6821.scope
    13207    cgroup_device   multi                          
    13380    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe88dc8c_de03_4a96_be89_bc283481d882.slice/cri-containerd-b020e4ad5d0089e84f6e5a31c33d756f8bad7483c0ee8fa6f265f30a2720d5ea.scope
    3834     cgroup_device   multi                          
    13343    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podfe88dc8c_de03_4a96_be89_bc283481d882.slice/cri-containerd-b958b088ad07d97ef4a7bc92a39ed84ee38e6cffb80196cfc1eb8730a5e7f266.scope
    3850     cgroup_device   multi                          
    13381    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod894550d3_b08c_4c96_80d6_76b29c9e8038.slice/cri-containerd-a84ad7732d863e18c6a683d641f4bdcb6dfc63d675ee0a252dce6e5586105800.scope
    13229    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod894550d3_b08c_4c96_80d6_76b29c9e8038.slice/cri-containerd-b87c096e24f3ee2f4b538816022bc9349824451735fbfe3bd25fd344e8c26f5e.scope
    13226    cgroup_device   multi                          
    13342    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod894550d3_b08c_4c96_80d6_76b29c9e8038.slice/cri-containerd-5ad502b56b7193e039694193b9dc8e8a3cba89dfbce6564c900f08ded542d251.scope
    13196    cgroup_device   multi                          
    13378    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod894550d3_b08c_4c96_80d6_76b29c9e8038.slice/cri-containerd-9a8e4675f35c77d28026511c973b72ac1e9273e3bf7f71464d2b6b1fcfab218c.scope
    13222    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9914a72_7cea_4daf_9903_baedf7ed7708.slice/cri-containerd-eb19336cd0c4ba1de68ebae304606295015cc568e847de39ef2ecccaf0f6722a.scope
    13042    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podf9914a72_7cea_4daf_9903_baedf7ed7708.slice/cri-containerd-c8fd6fd0b0e4f439f263f9a4c0aa048fd82cdd22d4bf270510355608352a8534.scope
    13031    cgroup_device   multi                          
    13351    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d749aea_92a4_40d7_ae42_39679cd850cd.slice/cri-containerd-5a6cedabfe3fdfc0153edaca94314316ad20da2e943de35b6f809150d3b77f8b.scope
    13192    cgroup_device   multi                          
    13391    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod7d749aea_92a4_40d7_ae42_39679cd850cd.slice/cri-containerd-b5d364912c6f4055ab8c066cc63a441c8cfd9873004e821e164195437ac951f2.scope
    13219    cgroup_device   multi                          
    13374    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcf970b06_b061_4192_96ca_1f8ce0c615f4.slice/cri-containerd-c048a0a21ad5983ca35d03cb2d5e1de73d72ef5afae05932a732156ae9a0df40.scope
    30860    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podcf970b06_b061_4192_96ca_1f8ce0c615f4.slice/cri-containerd-db2606bf2f63b4e3d9ac71222ecf7ea3318960ab9177d78a2cf9c457783ee162.scope
    30864    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d655a64_acaa_4f25_b074_a4468cd019c7.slice/cri-containerd-0f34830c87a97e9d5b392f49e6c662d415315caa34b059c5c4d0397fad1dce43.scope
    13203    cgroup_device   multi                          
    13371    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-pod2d655a64_acaa_4f25_b074_a4468cd019c7.slice/cri-containerd-ad857fe4cd166cc32305fbad7c3959a2db33cf77b183b396dc4646ec5708121b.scope
    13126    cgroup_device   multi                          
    13356    cgroup_device   multi                          
/run/cilium/cgroupv2/kubepods.slice/kubepods-besteffort.slice/kubepods-besteffort-podd73b2b29_d4b8_4ce5_8a32_b9a54b0b174e.slice/cri-containerd-ec9b11fa04246759a609387e2d5b245198a736d4fd06bdf8df6310b49c0ba5da.scope
    4111     cgroup_device   multi                          
    13347    cgroup_device   multi                          
