ls: cannot access '/proc//fd': No such file or directory
> Error while running 'ls -la /proc/$(pidof cilium-agent)/fd':  exit status 2

