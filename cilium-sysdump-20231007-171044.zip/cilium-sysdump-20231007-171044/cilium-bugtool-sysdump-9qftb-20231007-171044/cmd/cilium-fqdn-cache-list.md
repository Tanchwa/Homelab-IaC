Error: Error: Get "http://localhost/v1/fqdn/cache": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory

> Error while running 'cilium fqdn cache list':  exit status 1

