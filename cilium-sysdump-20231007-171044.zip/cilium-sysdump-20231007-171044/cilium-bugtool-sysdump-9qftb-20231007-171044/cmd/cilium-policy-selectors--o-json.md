Error: Cannot get policy: Get "http://localhost/v1/policy/selectors": dial unix /var/run/cilium/cilium.sock: connect: no such file or directory
Is the agent running?

> Error while running 'cilium policy selectors -o json':  exit status 1

